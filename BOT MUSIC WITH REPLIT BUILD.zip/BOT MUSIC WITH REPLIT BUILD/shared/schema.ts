import { pgTable, text, serial, integer, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Discord guild (server) schema
export const guilds = pgTable("guilds", {
  id: text("id").primaryKey(), // Discord guild ID (snowflake)
  name: text("name").notNull(),
  icon: text("icon"),
  memberCount: integer("member_count"),
  joinedAt: text("joined_at"), // ISO date string
  prefix: text("prefix").default("!"),
  defaultVolume: integer("default_volume").default(50),
  twentyFourSeven: boolean("twenty_four_seven").default(false), // Whether 24/7 mode is enabled
  twentyFourSevenChannelId: text("twenty_four_seven_channel_id"), // Voice channel ID for 24/7 mode
  updateChannelStatus: boolean("update_channel_status").default(true), // Whether to update voice channel name with current song
  autoplay: boolean("autoplay").default(true), // Autoplay enabled by default
});

export const insertGuildSchema = createInsertSchema(guilds);
export type InsertGuild = z.infer<typeof insertGuildSchema>;
export type Guild = typeof guilds.$inferSelect;

// Song schema for queue items
export const songs = pgTable("songs", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  url: text("url").notNull(),
  thumbnail: text("thumbnail"),
  duration: text("duration"),
  requestedBy: text("requested_by"),
  guildId: text("guild_id").notNull().references(() => guilds.id, { onDelete: "cascade" }),
  position: integer("position").notNull(),
});

export const insertSongSchema = createInsertSchema(songs);
export type InsertSong = z.infer<typeof insertSongSchema>;
export type Song = typeof songs.$inferSelect;

// Currently playing song for each guild
export const currentlyPlaying = pgTable("currently_playing", {
  guildId: text("guild_id").primaryKey().references(() => guilds.id, { onDelete: "cascade" }),
  songId: integer("song_id").references(() => songs.id, { onDelete: "set null" }),
  startTime: text("start_time"), // ISO date string
  pausedAt: text("paused_at"), // ISO date string, null if not paused
  currentPosition: text("current_position"), // Current position in the song (e.g., "1:30")
});

export const insertCurrentlyPlayingSchema = createInsertSchema(currentlyPlaying);
export type InsertCurrentlyPlaying = z.infer<typeof insertCurrentlyPlayingSchema>;
export type CurrentlyPlaying = typeof currentlyPlaying.$inferSelect;

// Bot statistics
export const statistics = pgTable("statistics", {
  id: serial("id").primaryKey(),
  uptime: text("uptime").notNull(), // ISO duration string
  totalGuilds: integer("total_guilds").notNull(),
  activeSessions: integer("active_sessions").notNull(),
  songsPlayed: integer("songs_played").notNull(),
  lastUpdated: text("last_updated").notNull(), // ISO date string
});

export const insertStatisticsSchema = createInsertSchema(statistics);
export type InsertStatistics = z.infer<typeof insertStatisticsSchema>;
export type Statistics = typeof statistics.$inferSelect;