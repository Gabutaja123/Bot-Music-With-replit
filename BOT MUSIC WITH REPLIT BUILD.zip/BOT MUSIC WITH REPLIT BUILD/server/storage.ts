import { 
  Guild, InsertGuild, 
  User, InsertUser, 
  Song, InsertSong, 
  CurrentlyPlaying, InsertCurrentlyPlaying,
  Statistics, InsertStatistics
} from "@shared/schema";

// Storage interface with CRUD methods for all entities
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Guild operations
  getGuild(id: string): Promise<Guild | undefined>;
  getGuilds(): Promise<Guild[]>;
  createGuild(guild: InsertGuild): Promise<Guild>;
  updateGuild(id: string, data: Partial<Guild>): Promise<Guild | undefined>;
  deleteGuild(id: string): Promise<boolean>;

  // 24/7 operations
  set24_7Mode(guildId: string, enabled: boolean, channelId?: string): Promise<Guild | undefined>;
  get24_7Guilds(): Promise<Guild[]>;

  // Song operations
  getSongById(id: number): Promise<Song | undefined>;
  getSongsByGuildId(guildId: string): Promise<Song[]>;
  addSongToQueue(song: InsertSong): Promise<Song>;
  removeSongFromQueue(id: number): Promise<boolean>;
  clearQueue(guildId: string): Promise<boolean>;
  updateSongPosition(id: number, position: number): Promise<Song | undefined>;

  // Currently playing operations
  getCurrentlyPlaying(guildId: string): Promise<CurrentlyPlaying | undefined>;
  setCurrentlyPlaying(data: InsertCurrentlyPlaying): Promise<CurrentlyPlaying>;
  updateCurrentlyPlaying(guildId: string, data: Partial<CurrentlyPlaying>): Promise<CurrentlyPlaying | undefined>;

  // Statistics operations
  getStatistics(): Promise<Statistics | undefined>;
  updateStatistics(data: Partial<Statistics>): Promise<Statistics | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private guilds: Map<string, Guild>;
  private songs: Map<number, Song>;
  private currentlyPlaying: Map<string, CurrentlyPlaying>;
  private stats: Statistics | undefined;
  private nextUserId: number;
  private nextSongId: number;

  constructor() {
    this.users = new Map();
    this.guilds = new Map();
    this.songs = new Map();
    this.currentlyPlaying = new Map();
    this.nextUserId = 1;
    this.nextSongId = 1;

    // Initialize default statistics
    this.stats = {
      id: 1,
      uptime: "PT0S", // ISO duration format
      totalGuilds: 0,
      activeSessions: 0,
      songsPlayed: 0,
      lastUpdated: new Date().toISOString()
    };
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.nextUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Guild operations
  async getGuild(id: string): Promise<Guild | undefined> {
    return this.guilds.get(id);
  }

  async getGuilds(): Promise<Guild[]> {
    return Array.from(this.guilds.values());
  }

  async createGuild(guild: InsertGuild): Promise<Guild> {
    this.guilds.set(guild.id, guild as Guild);

    // Update statistics
    if (this.stats) {
      this.stats.totalGuilds = this.guilds.size;
      this.stats.lastUpdated = new Date().toISOString();
    }

    return guild as Guild;
  }

  async updateGuild(id: string, data: Partial<Guild>): Promise<Guild | undefined> {
    const guild = await this.getGuild(id);
    if (!guild) return undefined;

    const updatedGuild = { ...guild, autoplay: true, ...data };
    this.guilds.set(id, updatedGuild);
    return updatedGuild;
  }

  async deleteGuild(id: string): Promise<boolean> {
    const deleted = this.guilds.delete(id);

    // Update statistics
    if (deleted && this.stats) {
      this.stats.totalGuilds = this.guilds.size;
      this.stats.lastUpdated = new Date().toISOString();
    }

    return deleted;
  }

  // 24/7 operations
  async set24_7Mode(guildId: string, enabled: boolean, channelId?: string): Promise<Guild | undefined> {
    const guild = await this.getGuild(guildId);
    if (!guild) return undefined;

    // Update the guild with 24/7 settings
    const updates: Partial<Guild> = { 
      twentyFourSeven: enabled
    };

    // Only set the channel ID if provided and enabled is true
    if (enabled && channelId) {
      updates.twentyFourSevenChannelId = channelId;
    } else if (!enabled) {
      updates.twentyFourSevenChannelId = null;
    }

    return this.updateGuild(guildId, updates);
  }

  async get24_7Guilds(): Promise<Guild[]> {
    return Array.from(this.guilds.values())
      .filter(guild => guild.twentyFourSeven === true);
  }

  // Song operations
  async getSongById(id: number): Promise<Song | undefined> {
    return this.songs.get(id);
  }

  async getSongsByGuildId(guildId: string): Promise<Song[]> {
    return Array.from(this.songs.values())
      .filter(song => song.guildId === guildId)
      .sort((a, b) => a.position - b.position);
  }

  async addSongToQueue(song: InsertSong): Promise<Song> {
    const id = this.nextSongId++;
    const newSong: Song = { ...song, id };
    this.songs.set(id, newSong);
    return newSong;
  }

  async removeSongFromQueue(id: number): Promise<boolean> {
    const song = this.songs.get(id);
    if (!song) return false;

    // Delete the song
    const deleted = this.songs.delete(id);

    // Reorder queue positions for remaining songs in the same guild
    if (deleted) {
      const guildSongs = Array.from(this.songs.values())
        .filter(s => s.guildId === song.guildId)
        .sort((a, b) => a.position - b.position);

      guildSongs.forEach((s, idx) => {
        s.position = idx;
        this.songs.set(s.id, s);
      });
    }

    return deleted;
  }

  async clearQueue(guildId: string): Promise<boolean> {
    const songsToDelete = Array.from(this.songs.values())
      .filter(song => song.guildId === guildId);

    songsToDelete.forEach(song => this.songs.delete(song.id));
    return true;
  }

  async updateSongPosition(id: number, position: number): Promise<Song | undefined> {
    const song = this.songs.get(id);
    if (!song) return undefined;

    const guildSongs = Array.from(this.songs.values())
      .filter(s => s.guildId === song.guildId)
      .sort((a, b) => a.position - b.position);

    // Remove the song from its current position
    const songIdx = guildSongs.findIndex(s => s.id === id);
    if (songIdx === -1) return undefined;
    guildSongs.splice(songIdx, 1);

    // Insert the song at the new position
    guildSongs.splice(position, 0, song);

    // Update all positions
    guildSongs.forEach((s, idx) => {
      s.position = idx;
      this.songs.set(s.id, s);
    });

    return this.songs.get(id);
  }

  // Currently playing operations
  async getCurrentlyPlaying(guildId: string): Promise<CurrentlyPlaying | undefined> {
    return this.currentlyPlaying.get(guildId);
  }

  async setCurrentlyPlaying(data: InsertCurrentlyPlaying): Promise<CurrentlyPlaying> {
    this.currentlyPlaying.set(data.guildId, data as CurrentlyPlaying);

    // Update statistics
    if (this.stats) {
      const activeSessionCount = this.currentlyPlaying.size;
      this.stats.activeSessions = activeSessionCount;
      this.stats.songsPlayed += 1;
      this.stats.lastUpdated = new Date().toISOString();
    }

    return data as CurrentlyPlaying;
  }

  async updateCurrentlyPlaying(guildId: string, data: Partial<CurrentlyPlaying>): Promise<CurrentlyPlaying | undefined> {
    const current = this.currentlyPlaying.get(guildId);
    if (!current) return undefined;

    const updated = { ...current, ...data };
    this.currentlyPlaying.set(guildId, updated);
    return updated;
  }

  // Statistics operations
  async getStatistics(): Promise<Statistics | undefined> {
    return this.stats;
  }

  async updateStatistics(data: Partial<Statistics>): Promise<Statistics | undefined> {
    if (!this.stats) return undefined;

    this.stats = { ...this.stats, ...data, lastUpdated: new Date().toISOString() };
    return this.stats;
  }
}

export const storage = new MemStorage();