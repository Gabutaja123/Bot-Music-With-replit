import { 
  Client, 
  VoiceBasedChannel
} from 'discord.js';
import { 
  AudioPlayer, 
  AudioResource,
  createAudioPlayer,
  createAudioResource,
  joinVoiceChannel,
  getVoiceConnection,
  VoiceConnectionStatus,
  entersState,
  StreamType,
  AudioPlayerStatus
} from '@discordjs/voice';
import { IStorage } from '../storage';
import play from 'play-dl';
import ytdl from '@distube/ytdl-core';

interface GuildQueueItem {
  title: string;
  url: string;
  thumbnail: string;
  duration: string;
  requestedBy: string;
}

interface GuildQueue {
  textChannel: string;
  voiceChannel: string;
  player: AudioPlayer;
  songs: GuildQueueItem[];
  volume: number;
  playing: boolean;
  loopMode: 'off' | 'song' | 'queue';
}

export class MusicManager {
  private client: Client;
  private storage: IStorage;
  private queues: Map<string, GuildQueue>;

  constructor(client: Client, storage: IStorage) {
    this.client = client;
    this.storage = storage;
    this.queues = new Map();

    // Handle bot disconnect
    this.client.on('voiceStateUpdate', (oldState, newState) => {
      // If the bot was disconnected
      if (oldState.member?.user.id === this.client.user?.id && oldState.channel && !newState.channel) {
        const guildId = oldState.guild.id;
        this.queues.delete(guildId);
        this.storage.clearQueue(guildId);
      }
    });
  }

  async addToQueue(guildId: string, query: string, requestedBy: string): Promise<any> {
    try {
      // Check if query is a URL or search term
      let searchResult;
      try {
        searchResult = await play.search(query, { limit: 1 });
      } catch (error) {
        console.error('Error searching for song:', error);
        throw new Error('Could not find the song');
      }

      if (!searchResult || searchResult.length === 0) {
        throw new Error('No results found');
      }

      const songInfo = searchResult[0];

      // Format duration
      let duration = '0:00';
      if (songInfo.durationInSec) {
        const minutes = Math.floor(songInfo.durationInSec / 60);
        const seconds = songInfo.durationInSec % 60;
        duration = `${minutes}:${seconds.toString().padStart(2, '0')}`;
      }

      // Create song object
      const song = {
        title: songInfo.title || 'Unknown Title',
        url: songInfo.url || query, // Fallback to original query if URL not available
        thumbnail: songInfo.thumbnails?.[0]?.url || '',
        duration,
        requestedBy
      };

      console.log('Adding song to queue:', {
        title: song.title,
        url: song.url,
        duration: song.duration
      });

      // Get guild queue
      const guildQueue = this.queues.get(guildId);

      // Get existing queue from storage to determine position
      const queueItems = await this.storage.getSongsByGuildId(guildId);
      const position = queueItems.length;

      // Add song to storage
      await this.storage.addSongToQueue({
        title: song.title,
        url: song.url,
        thumbnail: song.thumbnail,
        duration: song.duration,
        requestedBy: song.requestedBy,
        guildId,
        position
      });

      // If there's no queue, create one and start playing
      if (!guildQueue) {
        // For API calls, we can't directly start playing without voice channel info
        if (requestedBy === 'dashboard') {
          return song;
        }

        // Get guild
        const guild = this.client.guilds.cache.get(guildId);
        if (!guild) {
          throw new Error('Guild not found');
        }

        // Find a voice channel the user is in
        const member = guild.members.cache.find(m => m.user.username === requestedBy);
        if (!member) {
          throw new Error('Member not found');
        }

        const voiceChannel = member.voice.channel;
        if (!voiceChannel) {
          throw new Error('You must be in a voice channel to play music');
        }

        // Create new queue
        const player = createAudioPlayer();
        const newQueue: GuildQueue = {
          textChannel: '', // No text channel context in API calls
          voiceChannel: voiceChannel.id,
          player,
          songs: [song],
          volume: 50,
          playing: true,
          loopMode: 'off'
        };

        this.queues.set(guildId, newQueue);

        // Join voice channel and play
        try {
          await this.connectToChannel(voiceChannel);
          this.play(guildId);
        } catch (error) {
          console.error('Error playing song:', error);
          this.queues.delete(guildId);
          throw new Error('Could not join voice channel');
        }
      } else {
        // Add song to existing queue
        guildQueue.songs.push(song);
      }

      return song;
    } catch (error) {
      console.error('Error adding to queue:', error);
      throw error;
    }
  }

  async connectToChannel(channel: VoiceBasedChannel) {
    const connection = joinVoiceChannel({
      channelId: channel.id,
      guildId: channel.guild.id,
      adapterCreator: channel.guild.voiceAdapterCreator,
    });

    try {
      await entersState(connection, VoiceConnectionStatus.Ready, 30_000);
      return connection;
    } catch (error) {
      connection.destroy();
      throw error;
    }
  }

  async play(guildId: string) {
    const queue = this.queues.get(guildId);
    if (!queue || queue.songs.length === 0) {
      // Check if 24/7 mode is enabled before disconnecting
      const guild = await this.storage.getGuild(guildId);
      if (guild?.twentyFourSeven) {
        console.log(`Not disconnecting from ${guildId} due to 24/7 mode being enabled`);
        // Try to add a default playlist if queue is empty in 24/7 mode
        try {
          console.log('Adding default playlist for 24/7 mode');
          await this.addToQueue(
            guildId,
            "https://www.youtube.com/watch?v=IhVPlN3eVPE", // NCS playlist
            "System"
          );
          // This will play the newly added song
          return;
        } catch (error) {
          console.error('Failed to add default playlist in 24/7 mode:', error);
        }
      } else {
        // If 24/7 mode is not enabled, disconnect as usual
        const connection = getVoiceConnection(guildId);
        if (connection) {
          connection.destroy();
        }
        this.queues.delete(guildId);
        return;
      }
    }

    try {
      const song = queue.songs[0];

      console.log('Playing song:', {
        title: song.title,
        url: song.url,
        duration: song.duration
      });

      if (!song.url) {
        throw new Error("Song URL is undefined");
      }

      try {
        // Use ytdl-core directly (more reliable)
        console.log('Using ytdl-core for direct streaming');
        let songUrl = song.url;

        // If not a YouTube URL, search for it
        if (!songUrl.includes('youtube.com') && !songUrl.includes('youtu.be')) {
          console.log('URL is not from YouTube, searching for:', song.title);
          const searchResult = await play.search(song.title, { limit: 1 });
          if (searchResult && searchResult.length > 0) {
            songUrl = searchResult[0].url;
            console.log('Search successful, found URL:', songUrl);
          } else {
            throw new Error('No search results found');
          }
        }

        // Stream directly using ytdl-core
        console.log('Streaming from YouTube URL:', songUrl);
        const stream = ytdl(songUrl, {
          filter: 'audioonly',
          quality: 'highestaudio',
          highWaterMark: 1 << 25, // 32MB buffer
        });

        // Create resource
        const resource = createAudioResource(stream, { 
          inputType: StreamType.Arbitrary
        });

        // Play the resource
        queue.player.play(resource);

        // Set volume
        this.setVolumeInternal(queue, queue.volume);

        // Update currently playing in storage
        const queueItems = await this.storage.getSongsByGuildId(guildId);
        if (queueItems.length > 0) {
          await this.storage.setCurrentlyPlaying({
            guildId,
            songId: queueItems[0].id,
            startTime: new Date().toISOString(),
            pausedAt: null,
            currentPosition: '0:00'
          });
        }

        // Get voice connection
        const connection = getVoiceConnection(guildId);
        if (connection) {
          connection.subscribe(queue.player);
        }

        // Update voice channel status only when playing
        try {
          await this.updateVoiceChannelStatus(guildId, true);
        } catch (error) {
          console.error('Error updating voice channel status:', error);
        }

        // Handle song end
        queue.player.on(AudioPlayerStatus.Idle, async () => {
          // Handle looping
          if (queue.loopMode === 'song') {
            // Just replay the same song
            this.play(guildId);
          } else {
            // Remove the first song and play the next one
            if (queue.loopMode === 'queue') {
              // Move first song to the end of the queue
              const firstSong = queue.songs.shift();
              if (firstSong) {
                queue.songs.push(firstSong);
              }
            } else {
              // Get current song before removing
              const currentSong = queue.songs[0];

              // Remove first song from queue
              queue.songs.shift();

              // Remove from storage
              const queueItems = await this.storage.getSongsByGuildId(guildId);
              if (queueItems.length > 0) {
                await this.storage.removeSongFromQueue(queueItems[0].id);
              }

              // Always try to add related songs when queue ends
              if (queue.songs.length === 0 && currentSong) {
                try {
                  console.log('Searching for related songs to:', currentSong.title);
                  // Get multiple related songs
                  const searchResults = await play.search(`${currentSong.title} music similar`, { limit: 15 });
                  // Filter out duplicate songs and get random ones
                  const relatedSongs = searchResults.filter(result => 
                    result.url !== currentSong.url && 
                    !queue.songs.some(song => song.url === result.url)
                  );
                  
                  if (relatedSongs.length > 0) {
                    // Add 2-3 related songs to ensure continuous playback
                    const numSongsToAdd = Math.floor(Math.random() * 2) + 2;
                    for (let i = 0; i < numSongsToAdd && i < relatedSongs.length; i++) {
                      const randomIndex = Math.floor(Math.random() * relatedSongs.length);
                      const randomSong = relatedSongs[randomIndex];
                      console.log('Adding related song:', randomSong.title);
                      await this.addToQueue(guildId, randomSong.url, "Autoplay");
                      // Remove the song so it's not selected again
                      relatedSongs.splice(randomIndex, 1);
                    }
                  }
                } catch (error) {
                  console.error('Failed to add related songs:', error);
                }
              }
            }

            // Play next song
            this.play(guildId);
          }
        });
      } catch (innerError) {
        console.error('Error with ytdl-core:', innerError);
        // Try play-dl as a fallback
        try {
          console.log('Trying play-dl fallback for:', song.title);
          // Search directly with play-dl
          const searchResults = await play.search(song.title, { limit: 1 });
          if (!searchResults || searchResults.length === 0) {
            throw new Error('No search results found');
          }

          console.log('Found result with play-dl:', searchResults[0].title);
          const videoInfo = await play.video_info(searchResults[0].url);
          const stream = await play.stream_from_info(videoInfo);

          const resource = createAudioResource(stream.stream, { 
            inputType: stream.type as StreamType
          });

          queue.player.play(resource);

          // Get voice connection
          const connection = getVoiceConnection(guildId);
          if (connection) {
            connection.subscribe(queue.player);
          }

          // Update voice channel status only when playing
          try {
            await this.updateVoiceChannelStatus(guildId, true);
          } catch (error) {
            console.error('Error updating voice channel status:', error);
          }

          // Handle song end for fallback method too
          queue.player.on(AudioPlayerStatus.Idle, async () => {
            console.log('Song ended (fallback player)');
            // Handle looping
            if (queue.loopMode === 'song') {
              // Just replay the same song
              this.play(guildId);
            } else {
              // Remove the first song and play the next one
              if (queue.loopMode === 'queue') {
                // Move first song to the end of the queue
                const firstSong = queue.songs.shift();
                if (firstSong) {
                  queue.songs.push(firstSong);
                }
              } else {
                // Remove first song from queue
                queue.songs.shift();

                // Remove from storage
                const queueItems = await this.storage.getSongsByGuildId(guildId);
                if (queueItems.length > 0) {
                  await this.storage.removeSongFromQueue(queueItems[0].id);
                }
              }

              // Play next song
              this.play(guildId);
            }
          });
        } catch (fallbackError) {
          console.error('All fallback methods failed:', fallbackError);
          throw fallbackError;
        }
      }
    } catch (error) {
      console.error('Error playing song:', error);
      // Skip to next song on error
      queue.songs.shift();
      this.play(guildId);
    }
  }

  async pauseSong(guildId: string): Promise<{ success: boolean; message?: string }> {
    const queue = this.queues.get(guildId);
    if (!queue || !queue.playing) {
      return { success: false, message: 'Nothing is playing right now' };
    }

    queue.player.pause();
    queue.playing = false;

    // Update storage
    const currentlyPlaying = await this.storage.getCurrentlyPlaying(guildId);
    if (currentlyPlaying) {
      await this.storage.updateCurrentlyPlaying(guildId, {
        pausedAt: new Date().toISOString()
      });
    }

    return { success: true };
  }

  async resumeSong(guildId: string): Promise<{ success: boolean; message?: string }> {
    const queue = this.queues.get(guildId);
    if (!queue || queue.playing) {
      return { success: false, message: 'Nothing is paused right now' };
    }

    queue.player.unpause();
    queue.playing = true;

    // Update storage
    const currentlyPlaying = await this.storage.getCurrentlyPlaying(guildId);
    if (currentlyPlaying) {
      await this.storage.updateCurrentlyPlaying(guildId, {
        pausedAt: null
      });
    }

    return { success: true };
  }

  async togglePause(guildId: string): Promise<{ success: boolean; playing: boolean; message?: string }> {
    const queue = this.queues.get(guildId);
    if (!queue) {
      return { success: false, playing: false, message: 'Nothing is playing right now' };
    }

    if (queue.playing) {
      await this.pauseSong(guildId);
      return { success: true, playing: false };
    } else {
      await this.resumeSong(guildId);
      return { success: true, playing: true };
    }
  }

  async skipSong(guildId: string): Promise<{ success: boolean; message?: string }> {
    const queue = this.queues.get(guildId);
    if (!queue) {
      return { success: false, message: 'Nothing is playing right now' };
    }

    queue.player.stop();
    return { success: true };
  }

  async stopPlaying(guildId: string): Promise<{ success: boolean; message?: string }> {
    const queue = this.queues.get(guildId);
    if (!queue) {
      return { success: false, message: 'Nothing is playing right now' };
    }

    // Stop the player
    queue.player.stop();

    // Clear the queue
    queue.songs = [];
    await this.storage.clearQueue(guildId);

    // Get voice channel before deleting queue
    let voiceChannelId = null;
    try {
      const guild = this.client.guilds.cache.get(guildId);
      if (guild && queue) {
        const voiceChannel = guild.channels.cache.get(queue.voiceChannel);
        if (voiceChannel && voiceChannel.isVoiceBased()) {
          voiceChannelId = voiceChannel.id;

          // Reset channel name to default before disconnecting
          await voiceChannel.setName("Music");
        }
      }
    } catch (error) {
      console.error("Error resetting voice channel name:", error);
    }

    // Leave the voice channel
    const connection = getVoiceConnection(guildId);
    if (connection) {
      connection.destroy();
    }

    // Delete the queue
    this.queues.delete(guildId);

    // Clear currently playing
    const currentlyPlaying = await this.storage.getCurrentlyPlaying(guildId);
    if (currentlyPlaying) {
      await this.storage.updateCurrentlyPlaying(guildId, {
        pausedAt: null,
        currentPosition: '0:00'
      });
    }

    return { success: true, message: 'Stopped playing and left the voice channel' };
  }

  async setVolume(guildId: string, volume: number): Promise<{ success: boolean; message?: string }> {
    const queue = this.queues.get(guildId);
    if (!queue) {
      return { success: false, message: 'Nothing is playing right now' };
    }

    queue.volume = volume;
    this.setVolumeInternal(queue, volume);

    return { success: true };
  }

  private setVolumeInternal(queue: GuildQueue, volume: number) {
    // Discord.js volume is 0-1
    const normalizedVolume = volume / 100;
    // Implementation depends on voice adapter
  }

  async setLoopMode(guildId: string, mode: 'off' | 'song' | 'queue'): Promise<{ success: boolean; message?: string }> {
    const queue = this.queues.get(guildId);
    if (!queue) {
      return { success: false, message: 'Nothing is playing right now' };
    }

    queue.loopMode = mode;
    return { success: true };
  }

  getActiveConnections(): number {
    return this.queues.size;
  }

  getQueueForGuild(guildId: string): GuildQueue | undefined {
    return this.queues.get(guildId);
  }

  /**
   * Updates the voice channel status with the current song information
   * @param guildId The Discord guild ID
   * @param showSongInfo Whether to show the song info in the channel name
   */
  async updateVoiceChannelStatus(guildId: string, showSongInfo: boolean = true): Promise<boolean> {
    try {
      const guild = this.client.guilds.cache.get(guildId);
      if (!guild) {
        return false;
      }

      const queue = this.queues.get(guildId);
      if (!queue) {
        return false;
      }

      const voiceChannel = guild.channels.cache.get(queue.voiceChannel);
      if (!voiceChannel || !voiceChannel.isVoiceBased()) {
        return false;
      }

      // Get current song
      const currentSong = queue.songs[0];
      if (!currentSong) {
        return false;
      }

      if (showSongInfo) {
        // Create a status that shows what's playing - limited to 100 chars
        const songTitle = currentSong.title.length > 40 
          ? currentSong.title.substring(0, 37) + '...' 
          : currentSong.title;

        const status = `🎵 ${songTitle}`;
        await voiceChannel.setName(status);
      } else {
        // Reset the channel name to "Music" or something generic
        await voiceChannel.setName("Music");
      }

      return true;
    } catch (error) {
      console.error('Error updating voice channel status:', error);
      return false;
    }
  }
}