import { Client, GatewayIntentBits, Events, Collection, ActivityType } from 'discord.js';
import { IStorage } from '../storage';
import { initializeCommands } from './commands';
import { MusicManager } from './music';
import { formatDistanceToNow } from 'date-fns';

let botInstance: DiscordBot | null = null;

export class DiscordBot {
  client: Client;
  storage: IStorage;
  commands: Collection<string, any>;
  music: MusicManager;
  startTime: Date;

  constructor(storage: IStorage) {
    this.client = new Client({
      intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildVoiceStates,
      ],
    });
    this.storage = storage;
    this.commands = new Collection();
    this.music = new MusicManager(this.client, storage);
    this.startTime = new Date();

    // Initialize commands
    this.commands = initializeCommands(this);
  }

  async start() {
    if (!process.env.DISCORD_TOKEN) {
      throw new Error('Missing DISCORD_TOKEN environment variable');
    }

    this.client.once(Events.ClientReady, async (c) => {
      console.log(`Discord bot ready! Logged in as ${c.user.tag}`);
      
      // Set activity status
      this.client.user?.setActivity('music commands | !help', { type: ActivityType.Listening });
      
      // Initialize guilds in storage
      const guilds = this.client.guilds.cache.map(guild => ({
        id: guild.id,
        name: guild.name,
        icon: guild.iconURL() || undefined,
        memberCount: guild.memberCount,
        joinedAt: guild.joinedAt?.toISOString(),
        prefix: '!',
        defaultVolume: 50
      }));
      
      for (const guild of guilds) {
        const existingGuild = await this.storage.getGuild(guild.id);
        if (!existingGuild) {
          await this.storage.createGuild(guild);
        }
      }
      
      // Reconnect to 24/7 channels
      await this.reconnect24_7Guilds();
      
      // Update statistics
      await this.updateStatistics();
      
      // Set interval to update statistics every minute
      setInterval(() => this.updateStatistics(), 60000);
      
      // Set interval to check and reconnect 24/7 channels every 30 minutes
      setInterval(() => this.reconnect24_7Guilds(), 1800000);
    });

    this.client.on(Events.MessageCreate, async (message) => {
      // Ignore bot messages
      if (message.author.bot) return;
      
      // Get guild prefix
      const prefix = '!'; // Default prefix
      
      // Check if the message starts with the prefix
      if (!message.content.startsWith(prefix)) return;
      
      // Parse command and arguments
      const args = message.content.slice(prefix.length).trim().split(/ +/);
      const commandName = args.shift()?.toLowerCase();
      
      if (!commandName) return;
      
      // Execute command if it exists
      const command = this.commands.get(commandName);
      if (command) {
        try {
          await command.execute(message, args);
        } catch (error) {
          console.error(`Error executing command ${commandName}:`, error);
          await message.reply('There was an error executing that command!');
        }
      }
    });

    // Log in to Discord
    await this.client.login(process.env.DISCORD_TOKEN);
  }

  async updateStatistics() {
    try {
      // Calculate uptime
      const uptime = formatDistanceToNow(this.startTime);
      
      // Get total guilds
      const totalGuilds = this.client.guilds.cache.size;
      
      // Get active sessions (voice connections)
      const activeSessions = this.music.getActiveConnections();
      
      // Update statistics
      await this.storage.updateStatistics({
        uptime,
        totalGuilds,
        activeSessions,
        lastUpdated: new Date().toISOString()
      });
    } catch (error) {
      console.error('Error updating statistics:', error);
    }
  }

  async reconnect24_7Guilds() {
    try {
      console.log('Checking for 24/7 guilds to reconnect...');
      // Increase check frequency
      setInterval(() => this.reconnect24_7Guilds(), 300000); // Check every 5 minutes
      const twentyFourSevenGuilds = await this.storage.get24_7Guilds();
      
      if (twentyFourSevenGuilds.length > 0) {
        console.log(`Found ${twentyFourSevenGuilds.length} guilds with 24/7 mode enabled`);
        
        for (const guild of twentyFourSevenGuilds) {
          // Only reconnect if we have a channel ID and not already connected
          if (guild.twentyFourSevenChannelId) {
            const isConnected = this.client.voice?.adapters.has(guild.id);
            
            if (!isConnected) {
              console.log(`Reconnecting to 24/7 channel in guild ${guild.name} (${guild.id})`);
              
              try {
                // Get the guild instance from Discord
                const discordGuild = this.client.guilds.cache.get(guild.id);
                if (!discordGuild) {
                  console.log(`Guild ${guild.id} not found or bot is not a member`);
                  continue;
                }
                
                // Get the voice channel
                const channel = await discordGuild.channels.fetch(guild.twentyFourSevenChannelId);
                if (!channel || !channel.isVoiceBased()) {
                  console.log(`Channel ${guild.twentyFourSevenChannelId} not found or not a voice channel`);
                  continue;
                }
                
                // Connect to the channel
                await this.music.connectToChannel(channel);
                console.log(`Successfully reconnected to channel ${channel.name} in ${guild.name}`);
                
                // Check if there are songs in the queue
                const songs = await this.storage.getSongsByGuildId(guild.id);
                if (songs.length === 0) {
                  // Add a default playlist if queue is empty
                  await this.music.addToQueue(
                    guild.id,
                    "https://www.youtube.com/watch?v=IhVPlN3eVPE", // NCS playlist
                    "System"
                  );
                  console.log(`Added default playlist to guild ${guild.name}`);
                }
              } catch (error) {
                console.error(`Error reconnecting to voice channel in guild ${guild.id}:`, error);
              }
            } else {
              console.log(`Bot is already connected to a voice channel in guild ${guild.name}`);
            }
          }
        }
      } else {
        console.log('No guilds with 24/7 mode enabled');
      }
    } catch (error) {
      console.error('Error reconnecting to 24/7 guilds:', error);
    }
  }
  
  async stop() {
    this.client.destroy();
  }
}

export async function initialize(storage: IStorage): Promise<DiscordBot> {
  if (botInstance) {
    return botInstance;
  }

  botInstance = new DiscordBot(storage);
  await botInstance.start();
  return botInstance;
}

export function getBot(): DiscordBot | null {
  return botInstance;
}
