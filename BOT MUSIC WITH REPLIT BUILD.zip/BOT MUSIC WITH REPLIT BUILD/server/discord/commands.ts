import { Message, Collection, PermissionFlagsBits } from 'discord.js';
import type { DiscordBot } from './bot';

interface Command {
  name: string;
  description: string;
  category: 'Basic' | 'Queue' | 'Advanced';
  usage: string;
  execute: (message: Message, args: string[]) => Promise<void>;
}

export function initializeCommands(bot: DiscordBot): Collection<string, Command> {
  const commands = new Collection<string, Command>();

  // Play command
  commands.set('play', {
    name: 'play',
    description: 'Play a song from YouTube',
    category: 'Basic',
    usage: '!play [song name or URL]',
    execute: async (message: Message, args: string[]) => {
      if (!args.length) {
        return message.reply('You need to provide a song name or URL!');
      }

      const query = args.join(' ');
      
      // Check if user is in a voice channel
      if (!message.member?.voice.channel) {
        return message.reply('You need to be in a voice channel to play music!');
      }

      try {
        const result = await bot.music.addToQueue(
          message.guild!.id,
          query,
          message.author.username
        );
        
        const songEmbed = {
          color: 0x0099ff,
          title: 'Added to Queue',
          description: `**${result.title}**`,
          thumbnail: {
            url: result.thumbnail || 'https://i.imgur.com/GSL5QDx.png'
          },
          fields: [
            {
              name: 'Duration',
              value: result.duration || 'Unknown',
              inline: true
            },
            {
              name: 'Requested By',
              value: message.author.username,
              inline: true
            }
          ],
          timestamp: new Date().toISOString()
        };
        
        message.channel.send({ embeds: [songEmbed] });
      } catch (error) {
        console.error('Error adding song to queue:', error);
        message.reply('There was an error adding the song to queue!');
      }
    }
  });

  // Pause command
  commands.set('pause', {
    name: 'pause',
    description: 'Pause the current song',
    category: 'Basic',
    usage: '!pause',
    execute: async (message: Message) => {
      try {
        const result = await bot.music.pauseSong(message.guild!.id);
        if (result.success) {
          message.channel.send('⏸️ Music paused!');
        } else {
          message.reply(result.message || 'Nothing is playing right now!');
        }
      } catch (error) {
        console.error('Error pausing song:', error);
        message.reply('There was an error pausing the song!');
      }
    }
  });

  // Resume command
  commands.set('resume', {
    name: 'resume',
    description: 'Resume playback if paused',
    category: 'Basic',
    usage: '!resume',
    execute: async (message: Message) => {
      try {
        const result = await bot.music.resumeSong(message.guild!.id);
        if (result.success) {
          message.channel.send('▶️ Music resumed!');
        } else {
          message.reply(result.message || 'Nothing is paused right now!');
        }
      } catch (error) {
        console.error('Error resuming song:', error);
        message.reply('There was an error resuming the song!');
      }
    }
  });

  // Skip command
  commands.set('skip', {
    name: 'skip',
    description: 'Skip the current song',
    category: 'Basic',
    usage: '!skip',
    execute: async (message: Message) => {
      try {
        const result = await bot.music.skipSong(message.guild!.id);
        if (result.success) {
          message.channel.send('⏭️ Skipped to the next song!');
        } else {
          message.reply(result.message || 'Nothing is playing right now!');
        }
      } catch (error) {
        console.error('Error skipping song:', error);
        message.reply('There was an error skipping the song!');
      }
    }
  });
  
  // Stop command
  commands.set('stop', {
    name: 'stop',
    description: 'Stop playback and leave the voice channel',
    category: 'Basic',
    usage: '!stop',
    execute: async (message: Message) => {
      try {
        const result = await bot.music.stopPlaying(message.guild!.id);
        if (result.success) {
          message.channel.send('⏹️ Stopped playback and left the voice channel!');
        } else {
          message.reply(result.message || 'Nothing is playing right now!');
        }
      } catch (error) {
        console.error('Error stopping playback:', error);
        message.reply('There was an error stopping the playback!');
      }
    }
  });

  // Queue command
  commands.set('queue', {
    name: 'queue',
    description: 'Show the current queue',
    category: 'Queue',
    usage: '!queue',
    execute: async (message: Message) => {
      try {
        const guildId = message.guild!.id;
        const songs = await bot.storage.getSongsByGuildId(guildId);
        
        if (songs.length === 0) {
          return message.channel.send('The queue is empty!');
        }

        const queueEmbed = {
          color: 0x0099ff,
          title: '🎵 Current Queue',
          description: `${songs.length} songs in queue`,
          fields: songs.map((song, index) => ({
            name: `${index + 1}. ${song.title}`,
            value: `Duration: ${song.duration}\nRequested by: ${song.requestedBy}`,
            inline: false
          })),
          thumbnail: {
            url: songs[0].thumbnail || 'https://i.imgur.com/GSL5QDx.png'
          },
          timestamp: new Date().toISOString()
        };
        
        message.channel.send({ embeds: [queueEmbed] });
      } catch (error) {
        console.error('Error getting queue:', error);
        message.reply('There was an error getting the queue!');
      }
    }
  });

  // Clear command
  commands.set('clear', {
    name: 'clear',
    description: 'Clear the queue',
    category: 'Queue',
    usage: '!clear',
    execute: async (message: Message) => {
      try {
        const guildId = message.guild!.id;
        await bot.storage.clearQueue(guildId);
        message.channel.send('🧹 Queue cleared!');
      } catch (error) {
        console.error('Error clearing queue:', error);
        message.reply('There was an error clearing the queue!');
      }
    }
  });

  // Remove command
  commands.set('remove', {
    name: 'remove',
    description: 'Remove a song from the queue',
    category: 'Queue',
    usage: '!remove [position]',
    execute: async (message: Message, args: string[]) => {
      if (!args.length) {
        return message.reply('You need to provide a position in the queue!');
      }
      
      const position = parseInt(args[0]);
      if (isNaN(position) || position < 1) {
        return message.reply('Please provide a valid position number!');
      }
      
      try {
        const guildId = message.guild!.id;
        const songs = await bot.storage.getSongsByGuildId(guildId);
        
        if (songs.length === 0) {
          return message.channel.send('The queue is empty!');
        }
        
        if (position > songs.length) {
          return message.reply(`There are only ${songs.length} songs in the queue!`);
        }
        
        const songToRemove = songs[position - 1];
        await bot.storage.removeSongFromQueue(songToRemove.id);
        message.channel.send(`Removed **${songToRemove.title}** from the queue!`);
      } catch (error) {
        console.error('Error removing song from queue:', error);
        message.reply('There was an error removing the song from the queue!');
      }
    }
  });

  // Volume command
  commands.set('volume', {
    name: 'volume',
    description: 'Set the playback volume',
    category: 'Advanced',
    usage: '!volume [1-100]',
    execute: async (message: Message, args: string[]) => {
      if (!args.length) {
        return message.reply('You need to provide a volume level between 1 and 100!');
      }
      
      const volume = parseInt(args[0]);
      if (isNaN(volume) || volume < 1 || volume > 100) {
        return message.reply('Please provide a valid volume level between 1 and 100!');
      }
      
      try {
        const result = await bot.music.setVolume(message.guild!.id, volume);
        if (result.success) {
          message.channel.send(`🔊 Volume set to ${volume}%`);
        } else {
          message.reply(result.message || 'Nothing is playing right now!');
        }
      } catch (error) {
        console.error('Error setting volume:', error);
        message.reply('There was an error setting the volume!');
      }
    }
  });

  // Loop command
  commands.set('loop', {
    name: 'loop',
    description: 'Loop the current song or queue',
    category: 'Advanced',
    usage: '!loop [song/queue/off]',
    execute: async (message: Message, args: string[]) => {
      if (!args.length) {
        return message.reply('You need to specify `song`, `queue`, or `off`!');
      }
      
      const mode = args[0].toLowerCase();
      if (!['song', 'queue', 'off'].includes(mode)) {
        return message.reply('Please specify `song`, `queue`, or `off`!');
      }
      
      try {
        const result = await bot.music.setLoopMode(message.guild!.id, mode);
        if (result.success) {
          message.channel.send(`🔄 Loop mode set to: ${mode}`);
        } else {
          message.reply(result.message || 'Nothing is playing right now!');
        }
      } catch (error) {
        console.error('Error setting loop mode:', error);
        message.reply('There was an error setting the loop mode!');
      }
    }
  });

  // Help command
  commands.set('help', {
    name: 'help',
    description: 'Show available commands',
    category: 'Basic',
    usage: '!help [command]',
    execute: async (message: Message, args: string[]) => {
      if (!args.length) {
        // General help - list all commands grouped by category
        const categories = {
          Basic: [],
          Queue: [],
          Advanced: []
        };
        
        commands.forEach(cmd => {
          categories[cmd.category].push(`\`${cmd.name}\`: ${cmd.description}`);
        });
        
        const helpEmbed = {
          title: '🎵 Music Bot Commands',
          description: 'Here are all available commands:',
          fields: [
            {
              name: '🔹 Basic Commands',
              value: categories.Basic.join('\n') || 'No commands',
              inline: false
            },
            {
              name: '🔹 Queue Commands',
              value: categories.Queue.join('\n') || 'No commands',
              inline: false
            },
            {
              name: '🔹 Advanced Commands',
              value: categories.Advanced.join('\n') || 'No commands',
              inline: false
            }
          ],
          footer: {
            text: 'Type !help [command] for more info on a specific command'
          }
        };
        
        message.channel.send({ embeds: [helpEmbed] });
      } else {
        // Specific command help
        const commandName = args[0].toLowerCase();
        const command = commands.get(commandName);
        
        if (!command) {
          return message.reply(`Command \`${commandName}\` not found!`);
        }
        
        const commandEmbed = {
          title: `Command: ${command.name}`,
          fields: [
            {
              name: 'Description',
              value: command.description,
              inline: false
            },
            {
              name: 'Usage',
              value: command.usage,
              inline: false
            },
            {
              name: 'Category',
              value: command.category,
              inline: true
            }
          ]
        };
        
        message.channel.send({ embeds: [commandEmbed] });
      }
    }
  });

  // Setup command
  commands.set('setup', {
    name: 'setup',
    description: 'Configure bot settings for this server',
    category: 'Advanced',
    usage: '!setup',
    execute: async (message: Message) => {
      // Check if user has admin permissions
      if (!message.member?.permissions.has(PermissionFlagsBits.Administrator)) {
        return message.reply('You need administrator permissions to use this command!');
      }
      
      message.channel.send('Setup functionality will be available soon! For now, use the dashboard to configure the bot.');
    }
  });
  
  // 24/7 command
  commands.set('24/7', {
    name: '24/7',
    description: 'Set the bot to stay in voice channel 24/7',
    category: 'Advanced',
    usage: '!24/7 [on/off]',
    execute: async (message: Message, args: string[]) => {
      // Check if user has admin permissions
      if (!message.member?.permissions.has(PermissionFlagsBits.Administrator)) {
        return message.reply('You need administrator permissions to use this command!');
      }
      
      if (!args.length || !['on', 'off'].includes(args[0].toLowerCase())) {
        return message.reply('Please specify `on` or `off`!');
      }
      
      const enabled = args[0].toLowerCase() === 'on';
      const guildId = message.guild!.id;
      const channelId = message.member.voice.channelId;
      
      if (enabled && !channelId) {
        return message.reply('You need to be in a voice channel to enable 24/7 mode!');
      }
      
      try {
        // Update guild settings
        await bot.storage.set24_7Mode(guildId, enabled, channelId);
        
        // If enabled, connect to the channel if not already connected
        if (enabled && channelId) {
          const voiceChannel = await message.guild!.channels.fetch(channelId);
          if (voiceChannel && voiceChannel.isVoiceBased()) {
            try {
              await bot.music.connectToChannel(voiceChannel);
              message.channel.send(`🔄 24/7 mode enabled! I'll stay in <#${channelId}> until you turn it off.`);
              
              // If no songs in queue, add a default playlist
              const songs = await bot.storage.getSongsByGuildId(guildId);
              if (songs.length === 0) {
                await bot.music.addToQueue(
                  guildId,
                  "https://www.youtube.com/watch?v=IhVPlN3eVPE", // NCS playlist
                  "System"
                );
              }
            } catch (error) {
              console.error('Error connecting to voice channel:', error);
              message.reply('There was an error connecting to your voice channel!');
            }
          }
        } else {
          message.channel.send('🔄 24/7 mode disabled! I will disconnect when the queue is empty.');
        }
      } catch (error) {
        console.error('Error setting 24/7 mode:', error);
        message.reply('There was an error setting 24/7 mode!');
      }
    }
  });

  // Return commands collection
  return commands;
}

export async function getCommandsList(): Promise<any[]> {
  const commandsList = [
    {
      name: 'play',
      description: 'Play a song from YouTube',
      category: 'Basic',
      usage: '!play [song name or URL]'
    },
    {
      name: 'pause',
      description: 'Pause the current song',
      category: 'Basic',
      usage: '!pause'
    },
    {
      name: 'resume',
      description: 'Resume playback if paused',
      category: 'Basic',
      usage: '!resume'
    },
    {
      name: 'skip',
      description: 'Skip the current song',
      category: 'Basic',
      usage: '!skip'
    },
    {
      name: 'stop',
      description: 'Stop playback and leave the voice channel',
      category: 'Basic',
      usage: '!stop'
    },
    {
      name: 'queue',
      description: 'Show the current queue',
      category: 'Queue',
      usage: '!queue'
    },
    {
      name: 'clear',
      description: 'Clear the queue',
      category: 'Queue',
      usage: '!clear'
    },
    {
      name: 'remove',
      description: 'Remove a song from the queue',
      category: 'Queue',
      usage: '!remove [position]'
    },
    {
      name: 'loop',
      description: 'Loop the current song or queue',
      category: 'Advanced',
      usage: '!loop [song/queue/off]'
    },
    {
      name: 'volume',
      description: 'Set the playback volume',
      category: 'Advanced',
      usage: '!volume [1-100]'
    },
    {
      name: '24/7',
      description: 'Set the bot to stay in voice channel 24/7',
      category: 'Advanced',
      usage: '!24/7 [on/off]'
    },
    {
      name: 'help',
      description: 'Show available commands',
      category: 'Basic',
      usage: '!help [command]'
    }
  ];
  
  return commandsList;
}
