import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { initialize as initializeBot, getBot } from "./discord/bot";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Initialize Discord bot
  await initializeBot(storage);
  
  // API routes
  app.get("/api/status", async (_req: Request, res: Response) => {
    try {
      const bot = getBot();
      const stats = await storage.getStatistics();
      
      // If the bot isn't initialized yet, return an error
      if (!bot || !stats) {
        return res.status(503).json({ message: "Bot is starting up, please wait" });
      }
      
      return res.json({
        uptime: stats.uptime,
        serverCount: stats.totalGuilds,
        activeSessions: stats.activeSessions,
        songsPlayed: stats.songsPlayed
      });
    } catch (error) {
      console.error("Error fetching status:", error);
      return res.status(500).json({ message: "Failed to fetch bot status" });
    }
  });
  
  // Get all guilds
  app.get("/api/guilds", async (_req: Request, res: Response) => {
    try {
      const guilds = await storage.getGuilds();
      return res.json(guilds);
    } catch (error) {
      console.error("Error fetching guilds:", error);
      return res.status(500).json({ message: "Failed to fetch guilds" });
    }
  });
  
  // Get a specific guild
  app.get("/api/guilds/:id", async (req: Request, res: Response) => {
    try {
      const guild = await storage.getGuild(req.params.id);
      if (!guild) {
        return res.status(404).json({ message: "Guild not found" });
      }
      
      // Add Discord channels to the response if bot is available
      const bot = getBot();
      if (bot) {
        try {
          const discordGuild = bot.client.guilds.cache.get(req.params.id);
          if (discordGuild) {
            const channels = Array.from(discordGuild.channels.cache.values()).map(channel => ({
              id: channel.id,
              name: channel.name,
              type: channel.type
            }));
            return res.json({ ...guild, channels });
          }
        } catch (error) {
          console.error("Error fetching Discord channels:", error);
          // Continue and return the guild without channels
        }
      }
      
      return res.json(guild);
    } catch (error) {
      console.error("Error fetching guild:", error);
      return res.status(500).json({ message: "Failed to fetch guild" });
    }
  });
  
  // Get current queue for a guild
  app.get("/api/guilds/:id/queue", async (req: Request, res: Response) => {
    try {
      const songs = await storage.getSongsByGuildId(req.params.id);
      return res.json(songs);
    } catch (error) {
      console.error("Error fetching queue:", error);
      return res.status(500).json({ message: "Failed to fetch queue" });
    }
  });
  
  // Get currently playing song for a guild
  app.get("/api/guilds/:id/playing", async (req: Request, res: Response) => {
    try {
      const playing = await storage.getCurrentlyPlaying(req.params.id);
      if (!playing || !playing.songId) {
        return res.json(null);
      }
      
      const song = await storage.getSongById(playing.songId);
      if (!song) {
        return res.json(null);
      }
      
      return res.json({
        ...playing,
        song
      });
    } catch (error) {
      console.error("Error fetching currently playing:", error);
      return res.status(500).json({ message: "Failed to fetch currently playing" });
    }
  });
  
  // Add a song to queue
  app.post("/api/guilds/:id/queue", async (req: Request, res: Response) => {
    try {
      const guildId = req.params.id;
      const querySchema = z.object({
        query: z.string().min(1)
      });
      
      const parseResult = querySchema.safeParse(req.body);
      if (!parseResult.success) {
        return res.status(400).json({ message: "Invalid request body" });
      }
      
      const { query } = parseResult.data;
      const bot = getBot();
      
      if (!bot) {
        return res.status(503).json({ message: "Bot is not available" });
      }
      
      const result = await bot.music.addToQueue(guildId, query, "dashboard");
      return res.json(result);
    } catch (error) {
      console.error("Error adding to queue:", error);
      return res.status(500).json({ message: "Failed to add song to queue" });
    }
  });
  
  // Remove a song from queue
  app.delete("/api/guilds/:guildId/queue/:songId", async (req: Request, res: Response) => {
    try {
      const songId = parseInt(req.params.songId);
      if (isNaN(songId)) {
        return res.status(400).json({ message: "Invalid song ID" });
      }
      
      const success = await storage.removeSongFromQueue(songId);
      if (!success) {
        return res.status(404).json({ message: "Song not found" });
      }
      
      return res.json({ success: true });
    } catch (error) {
      console.error("Error removing from queue:", error);
      return res.status(500).json({ message: "Failed to remove song from queue" });
    }
  });
  
  // Skip current song
  app.post("/api/guilds/:id/skip", async (req: Request, res: Response) => {
    try {
      const guildId = req.params.id;
      const bot = getBot();
      
      if (!bot) {
        return res.status(503).json({ message: "Bot is not available" });
      }
      
      const result = await bot.music.skipSong(guildId);
      return res.json(result);
    } catch (error) {
      console.error("Error skipping song:", error);
      return res.status(500).json({ message: "Failed to skip song" });
    }
  });
  
  // Pause/resume playback
  app.post("/api/guilds/:id/pause-resume", async (req: Request, res: Response) => {
    try {
      const guildId = req.params.id;
      const bot = getBot();
      
      if (!bot) {
        return res.status(503).json({ message: "Bot is not available" });
      }
      
      const result = await bot.music.togglePause(guildId);
      return res.json(result);
    } catch (error) {
      console.error("Error toggling pause:", error);
      return res.status(500).json({ message: "Failed to toggle pause" });
    }
  });
  
  // Stop playback and leave voice channel
  app.post("/api/guilds/:id/stop", async (req: Request, res: Response) => {
    try {
      const guildId = req.params.id;
      const bot = getBot();
      
      if (!bot) {
        return res.status(503).json({ message: "Bot is not available" });
      }
      
      const result = await bot.music.stopPlaying(guildId);
      return res.json(result);
    } catch (error) {
      console.error("Error stopping playback:", error);
      return res.status(500).json({ message: "Failed to stop playback" });
    }
  });
  
  // 24/7 mode endpoints
  app.get("/api/guilds/:id/24-7", async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      
      const guild = await storage.getGuild(id);
      if (!guild) {
        return res.status(404).json({ message: "Guild not found" });
      }
      
      res.json({
        enabled: guild.twentyFourSeven || false,
        channelId: guild.twentyFourSevenChannelId || null
      });
    } catch (error) {
      console.error("Error getting 24/7 status:", error);
      return res.status(500).json({ message: "Failed to fetch 24/7 status" });
    }
  });
  
  app.post("/api/guilds/:id/24-7", async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      const { enabled, channelId } = req.body;
      
      if (typeof enabled !== 'boolean') {
        return res.status(400).json({ message: "Enabled parameter must be a boolean" });
      }
      
      // If enabling, channelId is required
      if (enabled && !channelId) {
        return res.status(400).json({ message: "Channel ID is required when enabling 24/7 mode" });
      }
      
      const bot = getBot();
      if (!bot) {
        return res.status(503).json({ message: "Bot is not available" });
      }
      
      const guild = await storage.getGuild(id);
      if (!guild) {
        return res.status(404).json({ message: "Guild not found" });
      }
      
      // Update guild settings
      const updatedGuild = await storage.set24_7Mode(id, enabled, channelId);
      
      // If enabling, need to connect to the channel if not already connected
      if (enabled && channelId) {
        const discordGuild = bot.client.guilds.cache.get(id);
        if (!discordGuild) {
          return res.status(404).json({ message: "Discord guild not found" });
        }
        
        try {
          const channel = await discordGuild.channels.fetch(channelId);
          if (!channel || !channel.isVoiceBased()) {
            return res.status(400).json({ message: "Channel not found or not a voice channel" });
          }
          
          // Connect to the channel
          await bot.music.connectToChannel(channel);
          
          // If no songs in queue, add a default playlist
          const songs = await storage.getSongsByGuildId(id);
          if (songs.length === 0) {
            await bot.music.addToQueue(
              id,
              "https://www.youtube.com/watch?v=IhVPlN3eVPE", // NCS playlist
              "System"
            );
          }
        } catch (error) {
          console.error("Error connecting to voice channel:", error);
          return res.status(500).json({ message: "Failed to connect to voice channel" });
        }
      }
      
      res.json({
        enabled: updatedGuild?.twentyFourSeven || false,
        channelId: updatedGuild?.twentyFourSevenChannelId || null
      });
    } catch (error) {
      console.error("Error setting 24/7 mode:", error);
      return res.status(500).json({ message: "Failed to set 24/7 mode" });
    }
  });
  
  // Voice channel status update endpoints
  app.get("/api/guilds/:id/channel-status", async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      
      const guild = await storage.getGuild(id);
      if (!guild) {
        return res.status(404).json({ message: "Guild not found" });
      }
      
      res.json({
        enabled: guild.updateChannelStatus || false
      });
    } catch (error) {
      console.error("Error getting channel status settings:", error);
      return res.status(500).json({ message: "Failed to fetch channel status settings" });
    }
  });
  
  app.post("/api/guilds/:id/channel-status", async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      const { enabled } = req.body;
      
      if (typeof enabled !== 'boolean') {
        return res.status(400).json({ message: "Enabled parameter must be a boolean" });
      }
      
      const bot = getBot();
      if (!bot) {
        return res.status(503).json({ message: "Bot is not available" });
      }
      
      const guild = await storage.getGuild(id);
      if (!guild) {
        return res.status(404).json({ message: "Guild not found" });
      }
      
      // Update guild settings
      const updatedGuild = await storage.updateGuild(id, {
        updateChannelStatus: enabled
      });
      
      // If disabling, reset the channel name
      if (!enabled) {
        try {
          // Find the current voice channel if any
          const queue = bot.music.getQueueForGuild(id);
          if (queue && queue.voiceChannel) {
            const discordGuild = bot.client.guilds.cache.get(id);
            if (discordGuild) {
              const voiceChannel = discordGuild.channels.cache.get(queue.voiceChannel);
              if (voiceChannel && voiceChannel.isVoiceBased()) {
                await voiceChannel.setName("Music");
              }
            }
          }
        } catch (error) {
          console.error("Error resetting channel name:", error);
          // Continue anyway
        }
      } else if (enabled) {
        // If enabling and currently playing, update the status
        try {
          const currentlyPlaying = await storage.getCurrentlyPlaying(id);
          if (currentlyPlaying && currentlyPlaying.songId) {
            // Update the voice channel with the current song
            await bot.music.updateVoiceChannelStatus(id, true);
          }
        } catch (error) {
          console.error("Error updating channel status:", error);
          // Continue anyway
        }
      }
      
      res.json({
        enabled: updatedGuild?.updateChannelStatus || false
      });
    } catch (error) {
      console.error("Error setting channel status:", error);
      return res.status(500).json({ message: "Failed to set channel status" });
    }
  });
  
  // Create HTTP server
  const httpServer = createServer(app);
  
  return httpServer;
}
