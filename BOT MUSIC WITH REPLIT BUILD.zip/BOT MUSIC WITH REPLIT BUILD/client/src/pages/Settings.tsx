import { useEffect, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Loader2, RefreshCw } from "lucide-react";

// Component to toggle voice channel status updates
interface VoiceChannelStatusToggleProps {
  guildId: string | null;
}

function VoiceChannelStatusToggle({ guildId }: VoiceChannelStatusToggleProps) {
  const { toast } = useToast();

  // Query to get current status (defaults to enabled)
  const { 
    data: channelStatus,
    isLoading
  } = useQuery<{ enabled: boolean }>({
    queryKey: ["/api/guilds", guildId, "channel-status"],
    enabled: !!guildId,
    queryFn: async () => {
      if (!guildId) return { enabled: true }; // Default to enabled
      const response = await apiRequest("GET", `/api/guilds/${guildId}/channel-status`);
      const data = await response.json();
      return data;
    }
  });

  // Query client for invalidation
  const queryClient = useQueryClient();

  // Mutation to update status
  const { 
    mutate: updateChannelStatus,
    isPending
  } = useMutation({
    mutationFn: async (enabled: boolean) => {
      if (!guildId) throw new Error("No guild selected");

      const response = await apiRequest("POST", `/api/guilds/${guildId}/channel-status`, { enabled });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to update channel status");
      }

      return response.json();
    },
    onSuccess: () => {
      // Invalidate the query to refetch data
      queryClient.invalidateQueries({ 
        queryKey: ["/api/guilds", guildId, "channel-status"] 
      });

      toast({
        title: "Settings updated",
        description: "Voice channel status settings have been saved"
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update settings",
        variant: "destructive"
      });
    }
  });

  if (isLoading) {
    return <Loader2 className="h-4 w-4 animate-spin" />;
  }

  return (
    <div className="flex items-center gap-2">
      <Switch 
        checked={channelStatus?.enabled || true} 
        disabled={isPending}
        onCheckedChange={(checked) => updateChannelStatus(checked)}
      />
      {channelStatus?.enabled && (
        <span className="text-xs text-green-500">Enabled</span>
      )}
    </div>
  );
}

// 24/7 Mode Component
interface TwentyFourSevenSectionProps {
  guildId: string | null;
}

function TwentyFourSevenSection({ guildId }: TwentyFourSevenSectionProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [enabled, setEnabled] = useState(false);
  const [selectedVoiceChannel, setSelectedVoiceChannel] = useState<string>("");

  // Voice channels query
  const { data: guild } = useQuery<{ channels?: Array<{ id: string, name: string, type: number }> }>({
    queryKey: ["/api/guilds", guildId],
    enabled: !!guildId,
    queryFn: async () => {
      if (!guildId) return { channels: [] };
      const response = await apiRequest("GET", `/api/guilds/${guildId}`);
      const data = await response.json();
      return data;
    }
  });

  // Get voice channels (type 2 is voice channel)
  const voiceChannels = guild?.channels?.filter(channel => channel.type === 2) || [];

  // 24/7 status query
  const { 
    data: twentyFourSevenStatus,
    isLoading: isLoadingStatus
  } = useQuery<{ enabled: boolean, channelId: string | null }>({
    queryKey: ["/api/guilds", guildId, "24-7"],
    enabled: !!guildId,
    queryFn: async () => {
      if (!guildId) return { enabled: false, channelId: null };
      const response = await apiRequest("GET", `/api/guilds/${guildId}/24-7`);
      const data = await response.json();
      return data;
    }
  });

  // Update state when data loads
  useEffect(() => {
    if (twentyFourSevenStatus) {
      setEnabled(twentyFourSevenStatus.enabled);
      if (twentyFourSevenStatus.channelId) {
        setSelectedVoiceChannel(twentyFourSevenStatus.channelId);
      } else if (voiceChannels.length > 0) {
        setSelectedVoiceChannel(voiceChannels[0].id);
      }
    }
  }, [twentyFourSevenStatus, voiceChannels]);

  // Mutation to update 24/7 settings
  const { 
    mutate: updateTwentyFourSeven,
    isPending: isUpdating 
  } = useMutation({
    mutationFn: async (data: { enabled: boolean, channelId?: string }) => {
      if (!guildId) throw new Error("No guild selected");

      const response = await apiRequest("POST", `/api/guilds/${guildId}/24-7`, data);

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to update 24/7 mode");
      }

      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/guilds", guildId, "24-7"] });
      toast({
        title: "24/7 Mode Updated",
        description: enabled 
          ? "Bot will now stay connected to the voice channel permanently" 
          : "Bot will disconnect when queue is empty",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to update 24/7 mode",
        description: error.message,
        variant: "destructive"
      });
    }
  });

  const handleToggle = (checked: boolean) => {
    setEnabled(checked);
    updateTwentyFourSeven({ 
      enabled: checked,
      channelId: checked ? selectedVoiceChannel : undefined
    });
  };

  const handleChannelChange = (value: string) => {
    setSelectedVoiceChannel(value);
    if (enabled) {
      updateTwentyFourSeven({ 
        enabled: true,
        channelId: value 
      });
    }
  };

  if (isLoadingStatus) {
    return (
      <div className="flex items-center gap-2 py-2">
        <Loader2 className="h-4 w-4 animate-spin" />
        <span>Loading 24/7 mode settings...</span>
      </div>
    );
  }

  return (
    <div className="bg-discord-dark border border-discord-channelbar rounded-md p-4 space-y-4">
      <div className="flex justify-between items-start">
        <div>
          <h3 className="text-base font-medium">24/7 Mode</h3>
          <p className="text-xs text-discord-light">
            Bot will stay in the selected voice channel permanently
          </p>
        </div>
        <Switch 
          checked={enabled}
          onCheckedChange={handleToggle}
          disabled={isUpdating || voiceChannels.length === 0}
        />
      </div>

      {enabled && (
        <div className="flex flex-col space-y-1.5">
          <Label htmlFor="voice-channel">Voice Channel</Label>
          <Select
            value={selectedVoiceChannel}
            onValueChange={handleChannelChange}
            disabled={isUpdating || voiceChannels.length === 0}
          >
            <SelectTrigger id="voice-channel" className="bg-discord-sidebar border-discord-channelbar focus:ring-discord-blurple">
              <SelectValue placeholder="Select a voice channel" />
            </SelectTrigger>
            <SelectContent>
              {voiceChannels.length === 0 ? (
                <div className="px-2 py-1 text-sm text-discord-light">No voice channels available</div>
              ) : (
                voiceChannels.map(channel => (
                  <SelectItem key={channel.id} value={channel.id}>
                    🔊 {channel.name}
                  </SelectItem>
                ))
              )}
            </SelectContent>
          </Select>
          <p className="text-xs text-discord-light mt-1">
            The bot will automatically reconnect to this channel if disconnected
          </p>
        </div>
      )}

      {isUpdating && (
        <div className="flex items-center gap-2 text-xs">
          <RefreshCw className="h-3 w-3 animate-spin" />
          <span>Updating settings...</span>
        </div>
      )}
    </div>
  );
}

export default function Settings() {
  const [selectedGuildId, setSelectedGuildId] = useState<string | null>(null);
  const { toast } = useToast();

  const { data: guilds = [], isLoading } = useQuery<Array<{ id: string, name: string }>>({
    queryKey: ["/api/guilds"],
    queryFn: async () => {
      const response = await apiRequest("GET", "/api/guilds");
      const data = await response.json();
      return data;
    }
  });

  // Set the first guild as selected when data loads
  useEffect(() => {
    if (guilds.length > 0 && !selectedGuildId) {
      setSelectedGuildId(guilds[0].id);
    }
  }, [guilds, selectedGuildId]);

  if (isLoading) {
    return (
      <div className="animate-pulse">
        <Skeleton className="h-12 w-full mb-6" />
        <Skeleton className="h-[400px] w-full" />
      </div>
    );
  }

  if (!guilds || guilds.length === 0) {
    return (
      <div className="text-center py-12 bg-discord-dark rounded-lg">
        <h2 className="text-2xl font-bold mb-4">No Discord Servers Found</h2>
        <p className="text-discord-light mb-6">
          The bot is not currently in any servers. Invite it to get started!
        </p>
        <button 
          className="px-4 py-2 bg-discord-blurple rounded-md hover:bg-opacity-80 transition"
          onClick={() => window.open("https://discord.com/api/oauth2/authorize?client_id=1370105735316377680&permissions=8&scope=bot", "_blank")}
        >
          Invite Bot to Server
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto">
      {guilds.length > 1 && (
        <div className="mb-6">
          <Label>Select Server</Label>
          <select 
            className="w-full bg-discord-dark text-white px-4 py-2 rounded border border-discord-light mt-1"
            value={selectedGuildId || ""}
            onChange={(e) => setSelectedGuildId(e.target.value)}
          >
            {guilds.map(guild => (
              <option key={guild.id} value={guild.id}>
                {guild.name}
              </option>
            ))}
          </select>
        </div>
      )}

      <Tabs defaultValue="general" className="w-full">
        <TabsList className="bg-discord-dark">
          <TabsTrigger value="general">General</TabsTrigger>
          <TabsTrigger value="permissions">Permissions</TabsTrigger>
          <TabsTrigger value="audio">Audio Settings</TabsTrigger>
        </TabsList>

        <TabsContent value="general">
          <Card className="bg-discord-dark border-discord-channelbar">
            <CardHeader>
              <CardTitle>General Settings</CardTitle>
              <CardDescription>Configure basic settings for the music bot.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex flex-col space-y-1.5">
                <Label htmlFor="prefix">Command Prefix</Label>
                <Input 
                  id="prefix" 
                  placeholder="!" 
                  defaultValue="!"
                  className="bg-discord-sidebar border-discord-channelbar focus:ring-discord-blurple"
                />
                <p className="text-xs text-discord-light mt-1">
                  All commands will start with this prefix
                </p>
              </div>

              <div className="flex justify-between items-center">
                <div>
                  <Label htmlFor="autoplay">Auto-play Related Songs</Label>
                  <p className="text-xs text-discord-light">
                    Automatically play related songs when the queue ends
                  </p>
                </div>
                <Switch id="autoplay" />
              </div>

              <div className="flex justify-between items-center">
                <div>
                  <Label htmlFor="announce">Announce Songs</Label>
                  <p className="text-xs text-discord-light">
                    Send a message in the channel when a new song starts playing
                  </p>
                </div>
                <Switch id="announce" defaultChecked />
              </div>

              <Button 
                className="bg-discord-blurple hover:bg-opacity-80 w-full mt-4"
                onClick={async () => {
                  try {
                    if (!selectedGuildId) return;
                    const response = await apiRequest(
                      "POST", 
                      `/api/guilds/${selectedGuildId}/settings`,
                      {
                        prefix: document.getElementById('prefix')?.value,
                        autoplay: (document.getElementById('autoplay') as HTMLInputElement)?.checked,
                        announce: (document.getElementById('announce') as HTMLInputElement)?.checked,
                        djRole: (document.getElementById('dj-role') as HTMLInputElement)?.checked,
                        userLimits: (document.getElementById('user-limits') as HTMLInputElement)?.checked,
                        defaultVolume: (document.getElementById('default-volume') as HTMLInputElement)?.value
                      }
                    );

                    if (!response.ok) {
                      throw new Error('Failed to save settings');
                    }

                    toast({
                      title: "Success",
                      description: "Settings have been saved successfully",
                    });
                  } catch (error) {
                    toast({
                      title: "Error",
                      description: "Failed to save settings",
                      variant: "destructive"
                    });
                  }
                }}
              >
                Save Changes
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="permissions">
          <Card className="bg-discord-dark border-discord-channelbar">
            <CardHeader>
              <CardTitle>Permission Settings</CardTitle>
              <CardDescription>Manage who can use music commands.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between items-center">
                <div>
                  <Label htmlFor="dj-role">DJ Role Required</Label>
                  <p className="text-xs text-discord-light">
                    Restrict music controls to users with a DJ role
                  </p>
                </div>
                <Switch id="dj-role" />
              </div>

              <div className="flex flex-col space-y-1.5">
                <Label htmlFor="dj-role-name">DJ Role Name</Label>
                <Input 
                  id="dj-role-name" 
                  placeholder="DJ" 
                  className="bg-discord-sidebar border-discord-channelbar focus:ring-discord-blurple"
                  disabled
                />
              </div>

              <div className="flex justify-between items-center">
                <div>
                  <Label htmlFor="user-limits">User Skip Voting</Label>
                  <p className="text-xs text-discord-light">
                    Allow users to vote to skip the current song
                  </p>
                </div>
                <Switch id="user-limits" defaultChecked />
              </div>

              <Button 
                className="bg-discord-blurple hover:bg-opacity-80 w-full mt-4"
                onClick={async () => {
                  try {
                    if (!selectedGuildId) return;

                    const response = await apiRequest(
                      "POST",
                      `/api/guilds/${selectedGuildId}/settings`,
                      {
                        djRole: (document.getElementById('dj-role') as HTMLInputElement)?.checked,
                        djRoleName: (document.getElementById('dj-role-name') as HTMLInputElement)?.value,
                        userLimits: (document.getElementById('user-limits') as HTMLInputElement)?.checked
                      }
                    );

                    if (!response.ok) {
                      throw new Error('Failed to save permission settings');
                    }

                    toast({
                      title: "Success",
                      description: "Permission settings have been saved successfully",
                    });
                  } catch (error) {
                    toast({
                      title: "Error",
                      description: "Failed to save permission settings",
                      variant: "destructive"
                    });
                  }
                }}
              >
                Save Changes
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="audio">
          <Card className="bg-discord-dark border-discord-channelbar">
            <CardHeader>
              <CardTitle>Audio Settings</CardTitle>
              <CardDescription>Configure audio quality and playback settings.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex flex-col space-y-1.5">
                <Label htmlFor="default-volume">Default Volume</Label>
                <div className="flex items-center space-x-2">
                  <Input 
                    id="default-volume" 
                    type="range" 
                    min="1" 
                    max="100" 
                    defaultValue="50"
                    className="bg-discord-sidebar border-discord-channelbar focus:ring-discord-blurple"
                  />
                  <span className="w-10 text-center">50%</span>
                </div>
              </div>

              <TwentyFourSevenSection guildId={selectedGuildId} />

              <div className="flex justify-between items-center">
                <div>
                  <Label htmlFor="stay-connected">Stay Connected</Label>
                  <p className="text-xs text-discord-light">
                    Bot stays in voice channel when queue ends
                  </p>
                </div>
                <Switch id="stay-connected" defaultChecked />
              </div>

              <div className="flex justify-between items-center">
                <div>
                  <Label htmlFor="update-channel-name">Update Voice Channel Status</Label>
                  <p className="text-xs text-discord-light">
                    Display the current playing song in voice channel name
                  </p>
                </div>
                <VoiceChannelStatusToggle guildId={selectedGuildId} />
              </div>

              <div className="flex flex-col space-y-1.5">
                <Label htmlFor="disconnect-timeout">Disconnect Timeout</Label>
                <Input 
                  id="disconnect-timeout" 
                  type="number" 
                  min="0" 
                  max="120" 
                  placeholder="5" 
                  defaultValue="0"
                  className="bg-discord-sidebar border-discord-channelbar focus:ring-discord-blurple"
                  disabled
                />
                <p className="text-xs text-discord-light mt-1">
                  Minutes to wait before disconnecting when idle (0 = stay connected)
                </p>
              </div>

              <Button 
                className="bg-discord-blurple hover:bg-opacity-80 w-full mt-4"
                onClick={async () => {
                  try {
                    if (!selectedGuildId) return;

                    const response = await apiRequest(
                      "POST",
                      `/api/guilds/${selectedGuildId}/settings`,
                      {
                        defaultVolume: document.getElementById('default-volume')?.value,
                        stayConnected: (document.getElementById('stay-connected') as HTMLInputElement)?.checked,
                        disconnectTimeout: document.getElementById('disconnect-timeout')?.value
                      }
                    );

                    if (!response.ok) {
                      throw new Error('Failed to save audio settings');
                    }

                    toast({
                      title: "Success",
                      description: "Audio settings have been saved successfully",
                    });
                  } catch (error) {
                    toast({
                      title: "Error",
                      description: "Failed to save audio settings",
                      variant: "destructive"
                    });
                  }
                }}
              >
                Save Changes
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}