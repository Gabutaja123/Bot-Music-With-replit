import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Button } from "@/components/ui/button";
import { ArrowUpRight } from "lucide-react";

export default function Help() {
  return (
    <div className="max-w-4xl mx-auto">
      <Card className="bg-discord-dark border-discord-channelbar mb-6">
        <CardHeader>
          <CardTitle>Help & Support</CardTitle>
          <CardDescription>Find answers to common questions about the music bot.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            <Button 
              className="bg-discord-blurple hover:bg-opacity-80 flex items-center justify-center gap-2"
              onClick={() => window.open("https://discord.gg/YOUR_SUPPORT_SERVER", "_blank")}
            >
              Join Support Server
              <ArrowUpRight className="h-4 w-4" />
            </Button>
            <Button 
              variant="outline" 
              className="border-discord-light hover:bg-discord-channelbar"
              onClick={() => window.open("https://github.com/REPLACE_WITH_GITHUB_USERNAME/discord-music-bot", "_blank")}
            >
              GitHub Repository
              <ArrowUpRight className="h-4 w-4 ml-2" />
            </Button>
          </div>
        </CardContent>
      </Card>
      
      <Card className="bg-discord-dark border-discord-channelbar">
        <CardHeader>
          <CardTitle>Frequently Asked Questions</CardTitle>
        </CardHeader>
        <CardContent>
          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="item-1" className="border-discord-channelbar">
              <AccordionTrigger className="hover:bg-discord-channelbar px-4 rounded-sm">
                How do I add the bot to my server?
              </AccordionTrigger>
              <AccordionContent className="text-discord-light px-4">
                Click the "Add to Server" button in the header or on the Dashboard page. You'll need to have the "Manage Server" permission in the Discord server you want to add the bot to.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="item-2" className="border-discord-channelbar">
              <AccordionTrigger className="hover:bg-discord-channelbar px-4 rounded-sm">
                The bot doesn't respond to commands!
              </AccordionTrigger>
              <AccordionContent className="text-discord-light px-4">
                Make sure the bot has the necessary permissions in your server and the text channel where you're using commands. The default prefix is "!" - try using "!help" to see if the bot responds.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="item-3" className="border-discord-channelbar">
              <AccordionTrigger className="hover:bg-discord-channelbar px-4 rounded-sm">
                How do I change the command prefix?
              </AccordionTrigger>
              <AccordionContent className="text-discord-light px-4">
                You can change the prefix in the Settings page. Navigate to the "General" tab and update the command prefix field.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="item-4" className="border-discord-channelbar">
              <AccordionTrigger className="hover:bg-discord-channelbar px-4 rounded-sm">
                The bot disconnects from voice channels!
              </AccordionTrigger>
              <AccordionContent className="text-discord-light px-4">
                This can happen if the bot is hosted on a free service with limitations. Our bot is designed to run 24/7, but occasional disconnects may occur. The bot will automatically try to reconnect and preserve your queue.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="item-5" className="border-discord-channelbar">
              <AccordionTrigger className="hover:bg-discord-channelbar px-4 rounded-sm">
                What music sources are supported?
              </AccordionTrigger>
              <AccordionContent className="text-discord-light px-4">
                Currently, the bot supports YouTube as a music source. You can provide YouTube URLs or search terms to find and play music.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="item-6" className="border-discord-channelbar">
              <AccordionTrigger className="hover:bg-discord-channelbar px-4 rounded-sm">
                The audio quality is poor or keeps cutting out
              </AccordionTrigger>
              <AccordionContent className="text-discord-light px-4">
                Audio quality depends on several factors including your Discord server region, internet connection, and server load. Try using a lower bitrate or switch to a server region closer to your location.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="item-7" className="border-discord-channelbar">
              <AccordionTrigger className="hover:bg-discord-channelbar px-4 rounded-sm">
                Is there a way to save playlists?
              </AccordionTrigger>
              <AccordionContent className="text-discord-light px-4">
                Playlist functionality is planned for a future update. For now, you can use the queue feature to add multiple songs.
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </CardContent>
      </Card>
    </div>
  );
}
