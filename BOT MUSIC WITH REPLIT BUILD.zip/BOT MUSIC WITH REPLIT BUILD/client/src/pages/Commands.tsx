import CommandsPanel from "@/components/CommandsPanel";

export default function Commands() {
  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-discord-dark rounded-lg p-6 mb-6">
        <h1 className="text-2xl font-bold mb-2">Music Bot Commands</h1>
        <p className="text-discord-light">
          Use these commands in any text channel where the bot has permissions. All commands use the <code className="bg-discord-sidebar px-1 py-0.5 rounded">!</code> prefix by default.
        </p>
      </div>
      
      <CommandsPanel />
    </div>
  );
}
