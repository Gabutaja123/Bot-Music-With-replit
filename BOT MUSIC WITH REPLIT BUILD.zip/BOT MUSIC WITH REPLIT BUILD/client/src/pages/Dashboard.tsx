import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import StatusPanel from "@/components/StatusPanel";
import CommandsPanel from "@/components/CommandsPanel";
import SetupGuide from "@/components/SetupGuide";
import { apiRequest } from "@/lib/queryClient";

export default function Dashboard() {
  const [selectedGuildId, setSelectedGuildId] = useState<string | null>(null);

  const { data: guilds = [], isLoading } = useQuery<Array<{ id: string, name: string }>>({
    queryKey: ["/api/guilds"],
    queryFn: async () => {
      const response = await apiRequest("GET", "/api/guilds");
      const data = await response.json();
      return data;
    }
  });
  
  // Set the first guild as selected when data loads
  useEffect(() => {
    if (guilds.length > 0 && !selectedGuildId) {
      setSelectedGuildId(guilds[0].id);
    }
  }, [guilds, selectedGuildId]);

  if (isLoading) {
    return (
      <div className="animate-pulse">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <Skeleton className="lg:col-span-2 h-96" />
          <Skeleton className="h-96" />
        </div>
        <Skeleton className="mt-6 h-64" />
      </div>
    );
  }

  if (!guilds || guilds.length === 0) {
    return (
      <div className="text-center py-12 bg-discord-dark rounded-lg">
        <h2 className="text-2xl font-bold mb-4">No Discord Servers Found</h2>
        <p className="text-discord-light mb-6">
          The bot is not currently in any servers. Invite it to get started!
        </p>
        <button 
          className="px-4 py-2 bg-discord-blurple rounded-md hover:bg-opacity-80 transition"
          onClick={() => window.open("https://discord.com/api/oauth2/authorize?client_id=1370105735316377680&permissions=8&scope=bot", "_blank")}
        >
          Invite Bot to Server
        </button>
      </div>
    );
  }

  return (
    <>
      {guilds.length > 1 && (
        <div className="mb-6 flex justify-end">
          <select 
            className="bg-discord-dark text-white px-4 py-2 rounded border border-discord-light"
            value={selectedGuildId || ""}
            onChange={(e) => setSelectedGuildId(e.target.value)}
          >
            {guilds.map(guild => (
              <option key={guild.id} value={guild.id}>
                {guild.name}
              </option>
            ))}
          </select>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {selectedGuildId && (
          <>
            <StatusPanel guildId={selectedGuildId} />
            <CommandsPanel />
          </>
        )}
      </div>
      
      <SetupGuide />
    </>
  );
}
