import { MicIcon, PlusIcon, SettingsIcon } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function SetupGuide() {
  return (
    <div className="mt-6 bg-discord-dark rounded-lg shadow-lg overflow-hidden">
      <div className="px-6 py-4 border-b border-discord-darker flex justify-between items-center">
        <h2 className="font-bold text-xl">Setup Guide</h2>
        <div className="px-2 py-1 rounded bg-discord-blurple text-xs font-semibold">
          24/7 Hosting
        </div>
      </div>
      
      <div className="p-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-discord-darker p-4 rounded-md">
            <div className="flex items-center space-x-3 mb-3">
              <div className="w-8 h-8 rounded-full bg-discord-blurple flex items-center justify-center">
                <PlusIcon className="h-4 w-4" />
              </div>
              <h3 className="font-bold">1. Add to Server</h3>
            </div>
            <p className="text-sm text-discord-light">Invite the bot to your Discord server with administrator permissions.</p>
            <Button 
              className="w-full mt-4 bg-discord-blurple hover:bg-opacity-80 transition text-sm"
              onClick={() => window.open("https://discord.com/api/oauth2/authorize?client_id=1370105735316377680&permissions=8&scope=bot", "_blank")}
            >
              Invite Bot
            </Button>
          </div>
          
          <div className="bg-discord-darker p-4 rounded-md">
            <div className="flex items-center space-x-3 mb-3">
              <div className="w-8 h-8 rounded-full bg-discord-blurple flex items-center justify-center">
                <MicIcon className="h-4 w-4" />
              </div>
              <h3 className="font-bold">2. Join Voice Channel</h3>
            </div>
            <p className="text-sm text-discord-light">Join a voice channel and use the !play command to start playing music.</p>
            <div className="w-full mt-4 px-4 py-2 bg-discord-darker border border-discord-light rounded text-center text-sm">
              !play [song name or URL]
            </div>
          </div>
          
          <div className="bg-discord-darker p-4 rounded-md">
            <div className="flex items-center space-x-3 mb-3">
              <div className="w-8 h-8 rounded-full bg-discord-blurple flex items-center justify-center">
                <SettingsIcon className="h-4 w-4" />
              </div>
              <h3 className="font-bold">3. Configure (Optional)</h3>
            </div>
            <p className="text-sm text-discord-light">Set up default volume, DJ roles, and command prefix for your server.</p>
            <div className="w-full mt-4 px-4 py-2 bg-discord-darker border border-discord-light rounded text-center text-sm">
              !setup
            </div>
          </div>
        </div>
        
        <div className="mt-6 bg-discord-darker p-4 rounded-md">
          <h3 className="font-bold mb-3">24/7 Hosting Details</h3>
          <p className="text-sm text-discord-light mb-4">
            This bot is configured to run 24/7 on Replit with UptimeRobot to prevent sleep. The bot will automatically reconnect to voice channels after disconnections.
          </p>
          <div className="flex flex-col md:flex-row md:space-x-4 space-y-2 md:space-y-0">
            <div className="flex-1 bg-discord-sidebar p-3 rounded-md">
              <div className="font-medium mb-1">Persistent Voice Connection</div>
              <p className="text-xs text-discord-light">Bot maintains connection to voice channels even after server restarts.</p>
            </div>
            <div className="flex-1 bg-discord-sidebar p-3 rounded-md">
              <div className="font-medium mb-1">Error Recovery</div>
              <p className="text-xs text-discord-light">Automatic handling of API rate limits and connection issues.</p>
            </div>
            <div className="flex-1 bg-discord-sidebar p-3 rounded-md">
              <div className="font-medium mb-1">Queue Memory</div>
              <p className="text-xs text-discord-light">Queue states preserved between bot restarts.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
