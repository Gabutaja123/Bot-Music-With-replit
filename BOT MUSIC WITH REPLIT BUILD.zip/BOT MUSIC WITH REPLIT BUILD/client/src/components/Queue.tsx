import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";
import { X } from "lucide-react";

interface Song {
  id: number;
  title: string;
  url: string;
  duration: string;
  thumbnail: string | null;
  requestedBy: string | null;
  position: number;
  guildId: string;
}

interface QueueProps {
  guildId: string;
}

export default function Queue({ guildId }: QueueProps) {
  const [songQuery, setSongQuery] = useState("");

  const { data: queue, isLoading } = useQuery<Song[]>({
    queryKey: [`/api/guilds/${guildId}/queue`],
    refetchInterval: 5000,
    queryFn: async () => {
      const response = await apiRequest("GET", `/api/guilds/${guildId}/queue`);
      return response.json();
    }
  });

  // Add song to queue
  const handleAddSong = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!songQuery.trim()) return;

    try {
      await apiRequest("POST", `/api/guilds/${guildId}/queue`, { query: songQuery });
      queryClient.invalidateQueries({ queryKey: [`/api/guilds/${guildId}/queue`] });
      setSongQuery("");
    } catch (error) {
      console.error("Failed to add song:", error);
    }
  };

  // Remove song from queue
  const handleRemoveSong = async (songId: number) => {
    try {
      await apiRequest("DELETE", `/api/guilds/${guildId}/queue/${songId}`, {});
      queryClient.invalidateQueries({ queryKey: [`/api/guilds/${guildId}/queue`] });
    } catch (error) {
      console.error("Failed to remove song:", error);
    }
  };

  if (isLoading) {
    return (
      <div className="bg-discord-darker rounded-lg overflow-hidden">
        <div className="px-4 py-3 border-b border-discord-channelbar flex justify-between items-center">
          <h3 className="font-bold">Queue</h3>
          <span className="text-sm text-discord-light">Loading...</span>
        </div>
        <div className="divide-y divide-discord-channelbar max-h-60 overflow-y-auto">
          {[1, 2, 3].map((i) => (
            <div key={i} className="p-3">
              <Skeleton className="h-6 w-full mb-1" />
              <Skeleton className="h-4 w-2/3" />
            </div>
          ))}
        </div>
        <div className="p-3 border-t border-discord-channelbar">
          <Skeleton className="h-10 w-full" />
        </div>
      </div>
    );
  }

  return (
    <div className="bg-discord-darker rounded-lg overflow-hidden">
      <div className="px-4 py-3 border-b border-discord-channelbar flex justify-between items-center">
        <h3 className="font-bold">Queue</h3>
        <span className="text-sm text-discord-light">
          {queue?.length ? `${queue.length} songs` : 'No songs in queue'}
        </span>
      </div>
      
      <div className="divide-y divide-discord-channelbar max-h-60 overflow-y-auto">
        {queue?.length === 0 && (
          <div className="p-3 text-center text-discord-light">
            The queue is empty. Add some songs!
          </div>
        )}
        
        {queue?.map((song: Song, index: number) => (
          <div key={song.id} className="flex items-center p-3 hover:bg-discord-channelbar transition">
            <div className="w-8 h-8 flex items-center justify-center text-discord-light">
              {index + 1}
            </div>
            <div className="ml-2 flex-1">
              <div className="font-medium">{song.title}</div>
              <div className="text-xs text-discord-light">
                Requested by: {song.requestedBy}
              </div>
            </div>
            <div className="text-sm text-discord-light">{song.duration}</div>
            <button 
              className="ml-4 text-discord-light hover:text-discord-red transition"
              onClick={() => handleRemoveSong(song.id)}
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        ))}
      </div>
      
      <div className="p-3 border-t border-discord-channelbar">
        <form className="flex space-x-2" onSubmit={handleAddSong}>
          <input 
            type="text" 
            placeholder="Add song to queue (YouTube URL or search)" 
            className="flex-1 bg-discord-sidebar rounded px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-discord-blurple"
            value={songQuery}
            onChange={(e) => setSongQuery(e.target.value)}
          />
          <button 
            type="submit" 
            className="bg-discord-blurple px-3 py-2 rounded hover:bg-opacity-80 transition"
          >
            <span className="text-xs">+</span>
          </button>
        </form>
      </div>
    </div>
  );
}
