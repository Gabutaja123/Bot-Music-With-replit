import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import CurrentlyPlaying from "@/components/CurrentlyPlaying";
import Queue from "@/components/Queue";
import { apiRequest } from "@/lib/queryClient";

interface StatusPanelProps {
  guildId: string;
}

export default function StatusPanel({ guildId }: StatusPanelProps) {
  const { data: status, isLoading } = useQuery({
    queryKey: ["/api/status"],
    refetchInterval: 30000, // Refresh every 30 seconds
    queryFn: async () => {
      const response = await apiRequest("GET", "/api/status");
      const data = await response.json();
      return data;
    }
  });

  if (isLoading) {
    return (
      <div className="lg:col-span-2 bg-discord-dark rounded-lg shadow-lg overflow-hidden">
        <div className="px-6 py-4 border-b border-discord-darker flex justify-between items-center">
          <Skeleton className="h-7 w-32" />
          <Skeleton className="h-4 w-24" />
        </div>
        
        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            {[1, 2, 3].map((i) => (
              <div key={i} className="bg-discord-darker rounded-md p-4">
                <Skeleton className="h-4 w-20 mb-1" />
                <Skeleton className="h-8 w-16" />
              </div>
            ))}
          </div>
          
          <Skeleton className="h-64 w-full mb-6" />
          <Skeleton className="h-64 w-full" />
        </div>
      </div>
    );
  }

  return (
    <div className="lg:col-span-2 bg-discord-dark rounded-lg shadow-lg overflow-hidden">
      <div className="px-6 py-4 border-b border-discord-darker flex justify-between items-center">
        <h2 className="font-bold text-xl">Bot Status</h2>
        <div className="flex space-x-2">
          <div className="flex items-center space-x-1 text-sm">
            <span className="w-2 h-2 rounded-full bg-discord-green"></span>
            <span>{status?.uptime || "Online"}</span>
          </div>
        </div>
      </div>
      
      <div className="p-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <div className="bg-discord-darker rounded-md p-4">
            <div className="text-discord-light text-sm mb-1">Servers</div>
            <div className="text-2xl font-bold">{status?.serverCount || 0}</div>
          </div>
          <div className="bg-discord-darker rounded-md p-4">
            <div className="text-discord-light text-sm mb-1">Active Sessions</div>
            <div className="text-2xl font-bold">{status?.activeSessions || 0}</div>
          </div>
          <div className="bg-discord-darker rounded-md p-4">
            <div className="text-discord-light text-sm mb-1">Songs Played</div>
            <div className="text-2xl font-bold">{status?.songsPlayed || 0}</div>
          </div>
        </div>

        <CurrentlyPlaying guildId={guildId} />
        <Queue guildId={guildId} />
      </div>
    </div>
  );
}
