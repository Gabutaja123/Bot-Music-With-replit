import React from "react";
import { useLocation } from "wouter";
import { Music, HomeIcon, ListOrdered, SettingsIcon, HelpCircleIcon } from "lucide-react";
import { cn } from "@/lib/utils";

export default function Sidebar() {
  const [location, setLocation] = useLocation();

  const navItems = [
    { 
      name: "MusicBot", 
      path: null, 
      icon: Music, 
      color: "bg-discord-blurple" 
    },
    { 
      name: "Dashboard", 
      path: "/", 
      icon: HomeIcon, 
      color: location === "/" ? "bg-discord-blurple" : "bg-discord-channelbar hover:bg-discord-blurple" 
    },
    { 
      name: "Commands", 
      path: "/commands", 
      icon: ListOrdered, 
      color: location === "/commands" ? "bg-discord-blurple" : "bg-discord-channelbar hover:bg-discord-blurple" 
    },
    { 
      name: "Settings", 
      path: "/settings", 
      icon: SettingsIcon, 
      color: location === "/settings" ? "bg-discord-blurple" : "bg-discord-channelbar hover:bg-discord-blurple" 
    },
    { 
      name: "Help", 
      path: "/help", 
      icon: HelpCircleIcon, 
      color: location === "/help" ? "bg-discord-blurple" : "bg-discord-channelbar hover:bg-discord-blurple" 
    },
  ];

  return (
    <div className="w-full md:w-20 bg-discord-sidebar flex flex-row md:flex-col items-center py-4 md:py-6 space-x-4 md:space-x-0 md:space-y-6 overflow-x-auto md:overflow-x-visible">
      {navItems.map((item, index) => (
        <React.Fragment key={item.name}>
          {index === 1 && (
            <div className="h-0.5 w-10 bg-discord-dark hidden md:block"></div>
          )}
          <div 
            className="flex flex-col items-center cursor-pointer"
            onClick={() => item.path && setLocation(item.path)}
          >
            <div className={cn("w-12 h-12 rounded-full flex items-center justify-center transition", item.color)}>
              <item.icon className={cn("text-white", { "text-discord-green": item.name === "Dashboard" && location === "/" })} />
            </div>
            <span className="text-xs text-discord-light mt-1 hidden md:block">{item.name}</span>
          </div>
        </React.Fragment>
      ))}
    </div>
  );
}
