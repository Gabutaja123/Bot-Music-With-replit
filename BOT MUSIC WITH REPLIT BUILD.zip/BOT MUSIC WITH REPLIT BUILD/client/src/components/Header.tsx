import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";

export default function Header() {
  const { data: status } = useQuery({
    queryKey: ["/api/status"],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  return (
    <header className="bg-discord-dark px-6 py-4 shadow-md flex justify-between items-center">
      <div className="flex items-center space-x-4">
        <h1 className="text-2xl font-bold">24/7 Music Bot</h1>
        <div className="px-2 py-1 rounded bg-discord-green text-xs font-semibold flex items-center">
          <span className="w-2 h-2 rounded-full bg-white mr-1"></span>
          ONLINE
        </div>
      </div>
      <div className="hidden md:flex items-center space-x-4">
        <Button 
          className="bg-discord-blurple hover:bg-opacity-80 transition flex items-center space-x-2"
          onClick={() => window.open("https://discord.com/api/oauth2/YOUR_BOT", "_blank")}
        >
          <span className="text-sm">+</span>
          <span>Add to Server</span>
        </Button>
        <Button 
          className="bg-discord-dark border border-discord-light hover:bg-discord-darker transition"
          variant="outline"
          onClick={() => window.open("https://discord.gg/SERVER_DISCORD", "_blank")}
        >
          Support Server
        </Button>
      </div>
    </header>
  );
}
