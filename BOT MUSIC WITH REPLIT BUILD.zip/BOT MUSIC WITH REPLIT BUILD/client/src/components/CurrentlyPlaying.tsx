import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";
import { Music, Pause, Play, SkipBack, SkipForward, Volume2, PlusSquare } from "lucide-react";

interface CurrentlyPlayingProps {
  guildId: string;
}

export default function CurrentlyPlaying({ guildId }: CurrentlyPlayingProps) {
  const [progress, setProgress] = useState(0);
  
  const { data: playing, isLoading } = useQuery({
    queryKey: [`/api/guilds/${guildId}/playing`],
    refetchInterval: 5000,
    queryFn: async () => {
      const response = await apiRequest("GET", `/api/guilds/${guildId}/playing`);
      return response.json();
    }
  });

  // Skip song
  const handleSkip = async () => {
    try {
      await apiRequest("POST", `/api/guilds/${guildId}/skip`, {});
      queryClient.invalidateQueries({ queryKey: [`/api/guilds/${guildId}/playing`] });
      queryClient.invalidateQueries({ queryKey: [`/api/guilds/${guildId}/queue`] });
    } catch (error) {
      console.error("Failed to skip song:", error);
    }
  };

  // Pause/resume playback
  const handlePlayPause = async () => {
    try {
      await apiRequest("POST", `/api/guilds/${guildId}/pause-resume`, {});
      queryClient.invalidateQueries({ queryKey: [`/api/guilds/${guildId}/playing`] });
    } catch (error) {
      console.error("Failed to toggle playback:", error);
    }
  };

  // Update progress bar
  useEffect(() => {
    if (!playing || !playing.song) {
      setProgress(0);
      return;
    }
    
    const isPaused = !!playing.pausedAt;
    const startTime = new Date(playing.startTime).getTime();
    const duration = parseDuration(playing.song.duration);
    
    if (isPaused) {
      const pausedTime = new Date(playing.pausedAt || '').getTime();
      const elapsed = pausedTime - startTime;
      const newProgress = Math.min(100, (elapsed / (duration * 1000)) * 100);
      setProgress(newProgress);
      return;
    }
    
    const interval = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const newProgress = Math.min(100, (elapsed / (duration * 1000)) * 100);
      setProgress(newProgress);
    }, 1000);
    
    return () => clearInterval(interval);
  }, [playing]);

  // Parse duration string (e.g., "3:45") to seconds
  const parseDuration = (duration: string): number => {
    const parts = duration.split(":");
    if (parts.length === 2) {
      return parseInt(parts[0]) * 60 + parseInt(parts[1]);
    }
    return 0;
  };

  // Format seconds to MM:SS
  const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, "0")}`;
  };

  // Calculate current time based on progress
  const getCurrentTime = (): string => {
    if (!playing || !playing.song) return "0:00";
    
    const duration = parseDuration(playing.song.duration);
    const currentSeconds = (progress / 100) * duration;
    return formatTime(currentSeconds);
  };

  if (isLoading) {
    return (
      <div className="bg-discord-darker rounded-lg p-4 mb-6">
        <h3 className="text-discord-light text-sm mb-3">CURRENTLY PLAYING</h3>
        <div className="flex flex-col md:flex-row items-center space-y-4 md:space-y-0">
          <Skeleton className="w-full md:w-36 h-36 rounded" />
          <div className="md:ml-4 flex-1">
            <Skeleton className="h-6 w-3/4 mb-1" />
            <Skeleton className="h-4 w-1/2 mb-3" />
            <Skeleton className="h-1 w-full mb-4" />
            <div className="flex justify-center space-x-6">
              <Skeleton className="h-8 w-8 rounded-full" />
              <Skeleton className="h-8 w-8 rounded-full" />
              <Skeleton className="h-8 w-8 rounded-full" />
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!playing || !playing.song) {
    return (
      <div className="bg-discord-darker rounded-lg p-4 mb-6">
        <h3 className="text-discord-light text-sm mb-3">CURRENTLY PLAYING</h3>
        <div className="flex items-center justify-center p-8">
          <div className="flex flex-col items-center text-discord-light">
            <Music className="h-12 w-12 mb-2" />
            <p>No music is currently playing</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-discord-darker rounded-lg p-4 mb-6">
      <h3 className="text-discord-light text-sm mb-3">CURRENTLY PLAYING</h3>
      <div className="flex flex-col md:flex-row items-center space-y-4 md:space-y-0">
        <img 
          src={playing.song.thumbnail} 
          alt={playing.song.title}
          className="w-full md:w-36 h-36 object-cover rounded"
          onError={(e) => {
            e.currentTarget.src = "https://via.placeholder.com/200x200?text=No+Thumbnail";
          }}
        />
        
        <div className="md:ml-4 flex-1">
          <div className="font-bold text-xl mb-1">{playing.song.title}</div>
          <div className="text-discord-light mb-3">Requested by: {playing.song.requestedBy}</div>
          
          <div className="flex items-center space-x-1 mb-4">
            <div className="text-xs text-discord-light">{getCurrentTime()}</div>
            <div className="flex-1 mx-2">
              <div className="h-1 bg-discord-darker rounded-full">
                <div 
                  className="h-1 bg-discord-blurple rounded-full" 
                  style={{ width: `${progress}%` }}
                ></div>
              </div>
            </div>
            <div className="text-xs text-discord-light">{playing.song.duration}</div>
          </div>
          
          <div className="flex justify-center space-x-6">
            <button 
              className="text-discord-light hover:text-white transition"
              onClick={handleSkip}
            >
              <SkipBack size={24} />
            </button>
            <button 
              className="text-discord-light hover:text-white transition"
              onClick={handlePlayPause}
            >
              {playing.pausedAt ? <Play size={24} /> : <Pause size={24} />}
            </button>
            <button 
              className="text-discord-light hover:text-white transition"
              onClick={handleSkip}
            >
              <SkipForward size={24} />
            </button>
            <button className="text-discord-light hover:text-white transition">
              <PlusSquare size={24} />
            </button>
            <button className="text-discord-light hover:text-white transition">
              <Volume2 size={24} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
