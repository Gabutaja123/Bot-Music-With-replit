import { useEffect, useState } from "react";
import { Skeleton } from "@/components/ui/skeleton";

interface Command {
  name: string;
  description: string;
  category: "Basic" | "Queue" | "Advanced";
  usage: string;
}

export default function CommandsPanel() {
  const [commands, setCommands] = useState<Command[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const commandsList: Command[] = [
      {
        name: "play",
        description: "Play a song from YouTube",
        category: "Basic",
        usage: "!play [song name or URL]"
      },
      {
        name: "pause",
        description: "Pause the current song",
        category: "Basic",
        usage: "!pause"
      },
      {
        name: "resume",
        description: "Resume playback if paused",
        category: "Basic",
        usage: "!resume"
      },
      {
        name: "skip",
        description: "Skip the current song",
        category: "Basic",
        usage: "!skip"
      },
      {
        name: "queue",
        description: "Show the current queue",
        category: "Queue",
        usage: "!queue"
      },
      {
        name: "clear",
        description: "Clear the queue",
        category: "Queue",
        usage: "!clear"
      },
      {
        name: "remove",
        description: "Remove a song from the queue",
        category: "Queue",
        usage: "!remove [position]"
      },
      {
        name: "loop",
        description: "Loop the current song or queue",
        category: "Advanced",
        usage: "!loop [song/queue/off]"
      },
      {
        name: "volume",
        description: "Set the playback volume",
        category: "Advanced",
        usage: "!volume [1-100]"
      },
      {
        name: "help",
        description: "Show available commands",
        category: "Basic",
        usage: "!help [command]"
      }
    ];
    
    setCommands(commandsList);
    setIsLoading(false);
  }, []);

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "Basic":
        return "bg-discord-green";
      case "Queue":
        return "bg-discord-yellow";
      case "Advanced":
        return "bg-discord-blurple";
      default:
        return "bg-discord-light";
    }
  };

  if (isLoading) {
    return (
      <div className="bg-discord-dark rounded-lg shadow-lg overflow-hidden">
        <div className="px-6 py-4 border-b border-discord-darker">
          <Skeleton className="h-7 w-48" />
        </div>
        <div className="p-4 overflow-y-auto" style={{ maxHeight: "720px" }}>
          <div className="space-y-4">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="bg-discord-darker p-4 rounded-md">
                <Skeleton className="h-6 w-32 mb-2" />
                <Skeleton className="h-4 w-full mb-2" />
                <Skeleton className="h-8 w-full" />
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-discord-dark rounded-lg shadow-lg overflow-hidden">
      <div className="px-6 py-4 border-b border-discord-darker">
        <h2 className="font-bold text-xl">Music Commands</h2>
      </div>
      
      <div className="p-4 overflow-y-auto" style={{ maxHeight: "720px" }}>
        <div className="space-y-4">
          {commands.map((command) => (
            <div key={command.name} className="bg-discord-darker p-4 rounded-md hover:bg-discord-channelbar transition">
              <div className="flex justify-between items-start mb-2">
                <div className="font-bold">!{command.name}</div>
                <div className={`text-xs px-2 py-1 rounded ${getCategoryColor(command.category)} text-white`}>
                  {command.category}
                </div>
              </div>
              <p className="text-sm text-discord-light mb-2">{command.description}</p>
              <div className="bg-discord-sidebar p-2 rounded text-xs font-mono">{command.usage}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
