import React from "react";
import Sidebar from "@/components/Sidebar";
import Header from "@/components/Header";

interface LayoutProps {
  children: React.ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-discord-darker text-white">
      <Sidebar />
      <div className="flex-1 overflow-hidden">
        <Header />
        <div className="p-6 overflow-y-auto" style={{ height: "calc(100vh - 72px)" }}>
          {children}
        </div>
      </div>
    </div>
  );
}
